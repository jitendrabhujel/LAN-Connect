from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.SignupPage, name='signup'),
    path('login/', views.LoginPage, name='login'),
    path('home/', views.HomePage, name='home'),  # Ensure this points to HomePage
    path('messages/', views.messages_page, name='messages'),
    path('logout/', views.logoutUser, name='logout'),
    path('video-call/', views.video_call, name='video_call'),
    path('fetch_chat_history/', views.fetch_chat_history, name='fetch_chat_history'),

]