import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from .models import ChatRoom, Message, FileAttachment, UserStatus, Presence, Thread, ChatMessage, ChatAttachment, CommunicationHistory, Group, GroupMessage, VideoCallRoom, VideoCallParticipant
from django.core.files.storage import default_storage
from django.utils import timezone
import base64
from django.db.models import Q
import traceback

# Imports for encryption
from django.conf import settings
from cryptography.fernet import Fernet
import hashlib

User = get_user_model()

# Encryption/Decryption Utilities
def get_encryption_key():
    # Derive a key from Django's SECRET_KEY.
    # IMPORTANT: This is a simplified approach for demonstration.
    # For production, use a robust key management system and store keys securely.
    # Ensure settings.SECRET_KEY is strong and kept secret.
    # The key must be 32 bytes URL-safe base64-encoded.
    # We hash the SECRET_KEY to ensure it fits the length requirement for Fernet.
    key = hashlib.sha256(settings.SECRET_KEY.encode()).digest()
    return base64.urlsafe_b64encode(key[:32]) # Use first 32 bytes of hash

try:
    cipher_suite = Fernet(get_encryption_key())
except Exception as e:
    print(f"CRITICAL: Failed to initialize Fernet cipher suite. Encryption/Decryption will fail. Error: {e}")
    cipher_suite = None # Ensure it's defined even if initialization fails

def encrypt_message(text):
    if not cipher_suite:
        print("ERROR: Cipher suite not available for encryption.")
        return text # Return plain text if encryption is not possible
    try:
        encrypted_text = cipher_suite.encrypt(text.encode())
        return encrypted_text.decode() # Store as string
    except Exception as e:
        print(f"Encryption error: {e}")
        return text # Fallback to plaintext on error

def decrypt_message(encrypted_text):
    if not cipher_suite:
        print("ERROR: Cipher suite not available for decryption.")
        return encrypted_text # Return as is if decryption is not possible
    try:
        # Ensure encrypted_text is bytes
        decrypted_text = cipher_suite.decrypt(encrypted_text.encode())
        return decrypted_text.decode()
    except Exception as e:
        print(f"Decryption error: {e}. Data might not be encrypted or key is wrong.")
        return encrypted_text # Fallback to returning original on error

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        if not self.user.is_authenticated:
            await self.close()
            return

        self.user_id = str(self.user.id)
        self.room_group_name = f'user_{self.user_id}'

        # Join user's personal room
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        # Update user presence
        await self.update_user_presence()
        await self.accept()

    async def disconnect(self, close_code):
        # Remove user presence
        await self.remove_user_presence()
        
        # Leave room group
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            
            # Handle video call signaling
            if data.get('type') == 'video-call':
                await self.handle_video_call(data)
                return

            # Handle group messages
            if data.get('is_group_message'):
                await self.handle_group_message(data)
                return

            # Handle one-to-one messages
            message_content = data.get('message', '')
            sent_by_id = str(data.get('sent_by'))
            send_to_id = str(data.get('send_to'))
            attachment_urls = data.get('attachment_urls', [])
            attachment_names = data.get('attachment_names', {})
            attachment_paths = data.get('attachment_paths', {})
            client_did_encrypt = data.get('client_did_encrypt', False)

            if not all([sent_by_id, send_to_id]):
                print("Missing user IDs in message data")
                return

            # Get or create thread
            thread = await self.get_or_create_thread(sent_by_id, send_to_id)
            if not thread:
                print(f"Failed to get/create thread for users {sent_by_id} and {send_to_id}")
                return

            # Save message
            chat_message_obj = await self.save_message(
                thread, sent_by_id, message_content, 
                attachment_urls, client_did_encrypt, 
                attachment_names, attachment_paths
            )
            if not chat_message_obj:
                print(f"Failed to save message for thread {thread.id}")
                return

            # Record communication history
            await self.record_communication(sent_by_id, send_to_id)

            # Prepare message data for broadcasting
            message_data = {
                'type': 'chat_message',
                'message': chat_message_obj.message,
                'sent_by': sent_by_id,
                'send_to': send_to_id,
                'thread_id': str(thread.id),
                'attachment_urls': attachment_urls,
                'attachment_names': attachment_names,
                'timestamp': chat_message_obj.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'is_encrypted': chat_message_obj.is_encrypted
            }

            # Send message to sender's room
            await self.channel_layer.group_send(
                f'user_{sent_by_id}',
                message_data
            )

            # Send message to recipient's room
            await self.channel_layer.group_send(
                f'user_{send_to_id}',
                message_data
            )

        except Exception as e:
            print(f"Error in receive: {str(e)}")
            print(traceback.format_exc())

    async def chat_message(self, event):
        # Send message to WebSocket
        await self.send(text_data=json.dumps(event))

    @database_sync_to_async
    def update_user_presence(self):
        Presence.update_presence(self.user, self.channel_name)

    @database_sync_to_async
    def remove_user_presence(self):
        Presence.remove_presence(self.channel_name)

    @database_sync_to_async
    def get_or_create_thread(self, user1_id, user2_id):
        try:
            user1 = User.objects.get(id=int(user1_id))
            user2 = User.objects.get(id=int(user2_id))
            
            # Try to find existing thread
            thread = Thread.objects.filter(
                Q(first_person=user1, second_person=user2) |
                Q(first_person=user2, second_person=user1)
            ).first()
            
            if not thread:
                # Create new thread with consistent ordering
                first_person = user1 if user1.id < user2.id else user2
                second_person = user2 if user1.id < user2.id else user1
                thread = Thread.objects.create(
                    first_person=first_person,
                    second_person=second_person
                )
                print(f"Created new thread {thread.id} between users {user1.id} and {user2.id}")
            
            return thread
        except Exception as e:
            print(f"Error in get_or_create_thread: {str(e)}")
            print(traceback.format_exc())
            return None

    @database_sync_to_async
    def save_message(self, thread, user_id, message, attachment_urls, 
                    client_did_encrypt=False, attachment_name_map=None, attachment_paths=None):
        try:
            user = User.objects.get(id=int(user_id))
            attachment_name_map = attachment_name_map or {}
            attachment_paths = attachment_paths or {}

            final_message_content = message
            message_is_encrypted_for_db = False

            if client_did_encrypt:
                # Message is already encrypted by the client for E2EE
                final_message_content = message # Store as is
                message_is_encrypted_for_db = True
            else:
                # Client sent plaintext (e.g., E2EE turned off for this 1-to-1 chat)
                # Store as plaintext. Server-side encryption for non-E2EE 1-to-1 is not applied here.
                final_message_content = message
                message_is_encrypted_for_db = False
            
            chat_message = ChatMessage.objects.create(
                thread=thread,
                user=user,
                message=final_message_content,
                is_encrypted=message_is_encrypted_for_db
            )
            
            print(f"[Consumer Save Msg] Att_urls: {attachment_urls}, Att_names: {attachment_name_map}, Att_paths: {attachment_paths}")

            for url in attachment_urls:
                relative_path = attachment_paths.get(url)
                original_name = attachment_name_map.get(url, url.split('/')[-1])

                if relative_path:
                    try:
                        ChatAttachment.objects.create(
                            chat_message=chat_message,
                            file=relative_path,
                            original_filename=original_name
                        )
                        print(f"[Consumer Save Attach] Saved attachment: RelPath='{relative_path}', OrigName='{original_name}' for msg {chat_message.id}")
                    except Exception as e:
                        print(f"[Consumer Save Attach] ERROR creating ChatAttachment for RelPath='{relative_path}': {str(e)}")

                else:
                    print(f"[Consumer Save Attach] WARNING: No relative_path found in attachment_paths for URL '{url}' for msg {chat_message.id}. Attachment not saved.")
            
            print(f"Saved message {chat_message.id} in thread {thread.id}, encrypted in DB: {chat_message.is_encrypted}, client_did_encrypt: {client_did_encrypt}")
            return chat_message
        except Exception as e:
            print(f"Error in save_message: {str(e)}")
            print(traceback.format_exc())
            return None

    @database_sync_to_async
    def record_communication(self, user1_id, user2_id):
        try:
            user1 = User.objects.get(id=int(user1_id))
            user2 = User.objects.get(id=int(user2_id))
            CommunicationHistory.record_communication(user1, user2)
            CommunicationHistory.record_communication(user2, user1)
            print(f"Recorded communication between users {user1.id} and {user2.id}")
        except Exception as e:
            print(f"Error in record_communication: {str(e)}")
            print(traceback.format_exc())

    async def handle_video_call(self, data):
        try:
            to_user_id = data.get('to')
            if not to_user_id:
                return

            # Add the sender's ID to the message
            data['from'] = self.user_id

            # Send to recipient's room
            await self.channel_layer.group_send(
                f'user_{to_user_id}',
                {
                    'type': 'video_call_message',
                    'message': data
                }
            )
        except Exception as e:
            print(f"Error in handle_video_call: {str(e)}")
            print(traceback.format_exc())

    async def video_call_message(self, event):
        # Send video call message to WebSocket
        await self.send(text_data=json.dumps(event['message']))

    async def handle_group_message(self, data):
        try:
            message = data.get('message', '')
            sent_by_id = str(data.get('sent_by'))
            group_id = str(data.get('group_id'))
            attachment_urls = data.get('attachment_urls', [])
            attachment_names = data.get('attachment_names', {})

            if not all([sent_by_id, group_id]):
                print("Missing group message data")
                return

            # Save group message
            sender = await database_sync_to_async(User.objects.get)(id=int(sent_by_id))
            group = await database_sync_to_async(Group.objects.get)(id=int(group_id))
            group_message = await database_sync_to_async(GroupMessage.objects.create)(
                group=group,
                sender=sender,
                message=message,
                attachment_urls=attachment_urls,
                attachment_names=attachment_names
            )

            # Get all group members
            member_ids = list(await database_sync_to_async(lambda: list(group.members.values_list('id', flat=True)))())

            # Prepare message data
            message_data = {
                'type': 'group_message',
                'message': message,
                'sent_by': sent_by_id,
                'sender_name': sender.username,
                'group_id': group_id,
                'attachment_urls': attachment_urls,
                'attachment_names': attachment_names,
                'timestamp': group_message.created_at.strftime('%Y-%m-%d %H:%M:%S')
            }

            # Send message to each group member's room, including the sender
            for member_id in member_ids:
                await self.channel_layer.group_send(
                    f'user_{member_id}',
                    message_data
                )
        except Exception as e:
            print(f"Error in handle_group_message: {str(e)}")
            print(traceback.format_exc())

    async def group_message(self, event):
        await self.send(text_data=json.dumps(event))

    async def handle_group_video_call_invite(self, data):
        group_id = str(data.get('group_id'))
        room_name = data.get('room_name')
        caller = self.scope['user'].username
        group = await database_sync_to_async(Group.objects.get)(id=int(group_id))
        member_ids = list(await database_sync_to_async(lambda: list(group.members.values_list('id', flat=True)))())
        for member_id in member_ids:
            if str(member_id) != str(self.user_id):
                await self.channel_layer.group_send(
                    f'user_{member_id}',
                    {
                        'type': 'group_call_invite',
                        'group_id': group_id,
                        'room_name': room_name,
                        'caller': caller
                    }
                )

    async def group_call_invite(self, event):
        await self.send(text_data=json.dumps({
            'type': 'group_call_invite',
            'group_id': event['group_id'],
            'room_name': event['room_name'],
            'caller': event['caller']
        }))

class VideoCallConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f'video_call_{self.room_name}'
        self.user = self.scope['user']
        self.pending_invites = set()  # Track pending invitations

        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

        # Send current participants list to the new user
        participants = await self.get_active_participants()
        await self.send(text_data=json.dumps({
            'type': 'participants_list',
            'participants': participants
        }))

    async def disconnect(self, close_code):
        try:
            # Update participant status
            if hasattr(self, 'user') and hasattr(self, 'room_name'):
                await self.update_participant_status(False)
            
            # Notify others about disconnection
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'user_disconnected',
                    'user_id': str(self.user.id),
                    'username': self.user.username
                }
            )
        except Exception as e:
            print(f"Error in disconnect: {str(e)}")
        finally:
            # Leave room group
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    @database_sync_to_async
    def get_active_participants(self):
        try:
            room = VideoCallRoom.objects.get(room_name=self.room_name)
            participants = VideoCallParticipant.objects.filter(
                room=room,
                is_active=True
            ).select_related('user')
            return [{
                'user_id': str(p.user.id),
                'username': p.user.username,
                'stream_id': p.stream_id
            } for p in participants]
        except Exception as e:
            print(f"Error getting active participants: {str(e)}")
            return []

    @database_sync_to_async
    def update_participant_status(self, is_active, stream_id=None):
        try:
            room = VideoCallRoom.objects.get(room_name=self.room_name)
            participant, created = VideoCallParticipant.objects.get_or_create(
                room=room,
                user=self.user,
                defaults={'is_active': is_active}
            )
            if not created:
                participant.is_active = is_active
                if stream_id:
                    participant.stream_id = stream_id
                participant.save()
            return True
        except Exception as e:
            print(f"Error updating participant status: {str(e)}")
            return False

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            action = data.get('action')

            if action == 'join':
                await self.handle_join(data)
            elif action == 'leave':
                await self.handle_leave(data)
            elif action == 'offer':
                await self.handle_offer(data)
            elif action == 'answer':
                await self.handle_answer(data)
            elif action == 'ice_candidate':
                await self.handle_ice_candidate(data)
            elif action == 'mute':
                await self.handle_mute(data)
            elif action == 'unmute':
                await self.handle_unmute(data)
            elif action == 'video_off':
                await self.handle_video_off(data)
            elif action == 'video_on':
                await self.handle_video_on(data)
            elif action == 'screen_share_start':
                await self.handle_screen_share_start(data)
            elif action == 'screen_share_stop':
                await self.handle_screen_share_stop(data)
            elif action == 'quality_change':
                await self.handle_quality_change(data)
            elif action == 'connection_status':
                await self.handle_connection_status(data)
            elif action == 'call_invite':
                await self.handle_call_invite(data)
            elif action == 'call_accept':
                await self.handle_call_accept(data)
            elif action == 'call_reject':
                await self.handle_call_reject(data)
        except Exception as e:
            print(f"Error in receive: {str(e)}")
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': str(e)
            }))

    async def handle_join(self, data):
        try:
            # Update participant status in database
            stream_id = data.get('stream_id')
            await self.update_participant_status(True, stream_id)

            # Notify all participants about the new user
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'user_joined',
                    'user_id': str(self.user.id),
                    'username': self.user.username,
                    'stream_id': stream_id
                }
            )
        except Exception as e:
            print(f"Error in handle_join: {str(e)}")

    async def handle_screen_share_start(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'screen_share_started',
                'user_id': str(self.user.id),
                'stream_id': data.get('stream_id')
            }
        )

    async def handle_screen_share_stop(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'screen_share_stopped',
                'user_id': str(self.user.id)
            }
        )

    async def handle_quality_change(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'quality_changed',
                'user_id': str(self.user.id),
                'quality': data.get('quality')
            }
        )

    async def handle_connection_status(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'connection_status_update',
                'user_id': str(self.user.id),
                'status': data.get('status')
            }
        )

    async def screen_share_started(self, event):
        await self.send(text_data=json.dumps(event))

    async def screen_share_stopped(self, event):
        await self.send(text_data=json.dumps(event))

    async def quality_changed(self, event):
        await self.send(text_data=json.dumps(event))

    async def connection_status_update(self, event):
        await self.send(text_data=json.dumps(event))

    async def user_disconnected(self, event):
        await self.send(text_data=json.dumps(event))

    async def handle_leave(self, data):
        # Send leave message to room group
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'participant_left',
                'user_id': data.get('user_id')
            }
        )

    async def handle_offer(self, data):
        # Forward offer to specific participant
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'offer',
                'offer': data.get('offer'),
                'from_user_id': data.get('from_user_id'),
                'to_user_id': data.get('to_user_id')
            }
        )

    async def handle_answer(self, data):
        # Forward answer to specific participant
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'answer',
                'answer': data.get('answer'),
                'from_user_id': data.get('from_user_id'),
                'to_user_id': data.get('to_user_id')
            }
        )

    async def handle_ice_candidate(self, data):
        # Forward ICE candidate to specific participant
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'ice_candidate',
                'candidate': data.get('candidate'),
                'from_user_id': data.get('from_user_id'),
                'to_user_id': data.get('to_user_id')
            }
        )

    async def handle_mute(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'mute',
                'user_id': data.get('user_id')
            }
        )

    async def handle_unmute(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'unmute',
                'user_id': data.get('user_id')
            }
        )

    async def handle_video_off(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'video_off',
                'user_id': data.get('user_id')
            }
        )

    async def handle_video_on(self, data):
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'video_on',
                'user_id': data.get('user_id')
            }
        )

    async def handle_call_invite(self, data):
        try:
            group_id = data.get('group_id')
            room_name = data.get('room_name')
            
            # Get group members
            group = await database_sync_to_async(Group.objects.get)(id=int(group_id))
            member_ids = await database_sync_to_async(lambda: list(group.members.values_list('id', flat=True)))()
            
            # Send invitation to all members except the caller
            for member_id in member_ids:
                if str(member_id) != str(self.user.id):
                    self.pending_invites.add(str(member_id))
                    await self.channel_layer.group_send(
                        f'user_{member_id}',
                        {
                            'type': 'call_invitation',
                            'group_id': group_id,
                            'room_name': room_name,
                            'caller_id': str(self.user.id),
                            'caller_name': self.user.username
                        }
                    )
        except Exception as e:
            print(f"Error in handle_call_invite: {str(e)}")

    async def handle_call_accept(self, data):
        try:
            group_id = data.get('group_id')
            room_name = data.get('room_name')
            
            # Remove from pending invites
            self.pending_invites.discard(str(self.user.id))
            
            # Notify all participants about acceptance
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'call_accepted',
                    'user_id': str(self.user.id),
                    'username': self.user.username,
                    'group_id': group_id,
                    'room_name': room_name
                }
            )
            
            # Update participant status
            await self.update_participant_status(True)
            
        except Exception as e:
            print(f"Error in handle_call_accept: {str(e)}")

    async def handle_call_reject(self, data):
        try:
            group_id = data.get('group_id')
            room_name = data.get('room_name')
            
            # Remove from pending invites
            self.pending_invites.discard(str(self.user.id))
            
            # Notify all participants about rejection
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'call_rejected',
                    'user_id': str(self.user.id),
                    'username': self.user.username,
                    'group_id': group_id,
                    'room_name': room_name
                }
            )
        except Exception as e:
            print(f"Error in handle_call_reject: {str(e)}")

    async def call_invitation(self, event):
        await self.send(text_data=json.dumps(event))

    async def call_accepted(self, event):
        await self.send(text_data=json.dumps(event))

    async def call_rejected(self, event):
        await self.send(text_data=json.dumps(event))