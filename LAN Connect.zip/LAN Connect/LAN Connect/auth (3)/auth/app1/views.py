import json
import os
import uuid

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.core.files.storage import default_storage
from django.db import transaction, models
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.core.exceptions import PermissionDenied

from .models import (
    Thread, Presence, CommunicationHistory,
    ChatMessage, ChatAttachment, Group, GroupMember,
    GroupMessage, VideoCall, VideoCallRoom, VideoCallParticipant,
    UserProfile
)

def superuser_required(function):
    def check_superuser(user):
        if not user.is_superuser or not user.is_staff:
            raise PermissionDenied
        return True
    decorated_function = user_passes_test(check_superuser)(function)
    return decorated_function

def signup_page(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        pass1 = request.POST.get('password1')
        pass2 = request.POST.get('password2')

        if not uname or not email or not pass1 or not pass2:
            messages.error(request, "All fields are required!")
            return redirect('signup')
        if pass1 != pass2:
            messages.error(request, "Passwords do not match!")
            return redirect('signup')
        if User.objects.filter(username=uname).exists():
            messages.error(request, "Username already exists!")
            return redirect('signup')
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
            return redirect('signup')

        user = User.objects.create_user(username=uname, email=email, password=pass1)
        messages.success(request, "User registered successfully!")
        return redirect('login')
    return render(request, 'signup.html')

def login_page(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=uname, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Log In To Your Account!")
            return redirect('home')
        else:
            messages.error(request, "Invalid username or password!")
            return redirect('login')
    return render(request, 'login.html')

@login_required
def home_page(request):
    # Get all users except the current user
    all_users = User.objects.exclude(id=request.user.id)
    
    # Get active users
    active_users = Presence.get_active_users().exclude(id=request.user.id)
    
    # Get users with their online status
    users_with_status = []
    for user in all_users:
        # Try to get the user's profile picture URL
        try:
            profile_pic_url = user.profile.profile_pic.url if user.profile.profile_pic else '/static/img/default-avatar.svg'
        except Exception:
            profile_pic_url = '/static/img/default-avatar.svg'
        users_with_status.append({
            'user': user,
            'is_active': Presence.is_user_active(user),
            'profile_pic_url': profile_pic_url
        })
    
    # Get all threads where the current user is involved
    threads = Thread.objects.by_user(user=request.user).prefetch_related('chat_message_thread').order_by('-updated')
    
    # Get recent communications
    communicated_users = CommunicationHistory.objects.filter(
        user=request.user
    ).order_by('-last_communicated').select_related('communicated_with')
    
    # Get all groups the user is a member of
    groups = Group.objects.filter(members=request.user).select_related('creator').prefetch_related('members')
    
    # Get recent messages for each thread
    recent_messages = []
    for thread in threads:
        last_message = ChatMessage.objects.filter(thread=thread).order_by('-timestamp').first()
        if last_message:
            other_user = thread.first_person if thread.first_person != request.user else thread.second_person
            recent_messages.append({
                'thread_id': str(thread.id),
                'other_user_id': str(other_user.id),
                'other_user_name': other_user.username,
                'last_message': last_message.message,
                'timestamp': last_message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'timestamp_unix': int(last_message.timestamp.timestamp()),
                'is_read': last_message.is_read if last_message.user != request.user else True,
                'is_active': Presence.is_user_active(other_user)
            })
    
    context = {
        'users_with_status': users_with_status,
        'Threads': threads,
        'user': request.user,
        'communicated_users': communicated_users,
        'current_time': timezone.now(),
        'groups': groups,
        'recent_messages': sorted(recent_messages, key=lambda x: x['timestamp_unix'], reverse=True)
    }
    return render(request, 'home.html', context)

def logout_user(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('login')

@login_required
def messages_page(request):
    all_users = User.objects.exclude(id=request.user.id)
    active_users = Presence.get_active_users().exclude(id=request.user.id)
    users_with_status = []
    for user in all_users:
        users_with_status.append({
            'user': user,
            'is_active': Presence.is_user_active(user)
        })
    threads = Thread.objects.by_user(user=request.user).prefetch_related('chat_message_thread').order_by('timestamp')
    communicated_users = CommunicationHistory.objects.filter(user=request.user).order_by('-last_communicated')
    
    # Get all groups the user is a member of
    groups = Group.objects.filter(members=request.user).select_related('creator').prefetch_related('members')
    
    context = {
        'users_with_status': users_with_status,
        'Threads': threads,
        'user': request.user,
        'communicated_users': communicated_users,
        'current_time': timezone.now(),
        'groups': groups,  # Add groups to the context
    }
    return render(request, 'home.html', context)

@login_required
def video_call(request, call_id=None, group_id=None):
    context = {
        'call_id': call_id,
        'is_group_call': bool(group_id),
        'group_id': group_id
    }
    return render(request, 'video_call.html', context)

@csrf_exempt
def upload_file(request):
    if request.method == 'POST':
        if not request.FILES:
            return JsonResponse({'error': 'No files were uploaded.'}, status=400)

        files = request.FILES.getlist('files')
        if not files:
            return JsonResponse({'error': 'File list is empty in request.'}, status=400)

        attachment_urls = []
        attachment_names = {}
        attachment_paths = {}

        print(f"[Upload View] Received {len(files)} file(s) for upload.")

        for file_obj in files:
            try:
                original_file_name = os.path.basename(file_obj.name)
                
                file_ext = original_file_name.split('.')[-1].lower()
                unique_file_stem = f"{os.path.splitext(original_file_name)[0]}_{timezone.now().strftime('%Y%m%d_%H%M%S_%f')}"
                unique_file_name = f"{unique_file_stem}.{file_ext}"

                if file_ext in ['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif', 'svg', 'ico']:
                    sub_dir = 'images'
                elif file_ext in ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv']:
                    sub_dir = 'videos'
                elif file_ext in ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv']:
                    sub_dir = 'documents'
                else:
                    sub_dir = 'others'
                
                save_dir_relative = os.path.join('chat_attachments', sub_dir)
                
                file_path_relative = os.path.join(save_dir_relative, unique_file_name)
                
                saved_path = default_storage.save(file_path_relative, file_obj) 
                
                file_url = default_storage.url(saved_path)
                
                attachment_urls.append(file_url)
                attachment_names[file_url] = original_file_name
                attachment_paths[file_url] = saved_path

                print(f"[Upload View] Saved '{original_file_name}' as '{saved_path}', URL: '{file_url}'")

            except Exception as e:
                print(f"[Upload View] Error processing file '{file_obj.name}': {str(e)}")
                return JsonResponse({'error': f'Error processing file {file_obj.name}: {str(e)}'}, status=500)
            
        if not attachment_urls:
            return JsonResponse({'error': 'No files were successfully processed.'}, status=500)

        return JsonResponse({
            'attachment_urls': attachment_urls,
            'attachment_names': attachment_names,
            'attachment_paths': attachment_paths
        })

    return JsonResponse({'error': 'Invalid request method. Only POST is allowed.'}, status=405)

@login_required
def fetch_chat_history(request):
    other_user_id = request.GET.get('other_user_id')
    current_user_id = request.GET.get('current_user_id')

    if not other_user_id or not current_user_id:
        return JsonResponse({'error': 'Missing user IDs'}, status=400)

    try:
        current_user = User.objects.get(id=current_user_id)
        other_user = User.objects.get(id=other_user_id)

        # Find thread between users (in either direction)
        thread = Thread.objects.filter(
            (Q(first_person=current_user, second_person=other_user) |
            Q(first_person=other_user, second_person=current_user))
        ).first()

        # If no thread exists, create one with consistent ordering
        if not thread:
            thread = Thread.objects.create(
                first_person=min(current_user, other_user, key=lambda x: x.id),
                second_person=max(current_user, other_user, key=lambda x: x.id)
            )

        # Record communication history for both users
        CommunicationHistory.record_communication(current_user, other_user)
        CommunicationHistory.record_communication(other_user, current_user)

        # Get messages from the last 24 hours
        chat_messages = ChatMessage.get_messages_within_24h(thread)
        messages = []
        
        for msg in chat_messages:
            # Get all attachments for this message
            attachments = ChatAttachment.objects.filter(chat_message=msg)
            attachment_urls = [attachment.file.url for attachment in attachments]
            # Populate attachment_names for historical messages
            attachment_names_for_msg = {}
            for attachment in attachments:
                # Fallback: Use os.path.basename if original_filename is not stored/available
                # This assumes attachment.file.name is the path from which basename can be extracted.
                # Ideally, ChatAttachment model would store the original filename.
                try:
                    attachment_names_for_msg[attachment.file.url] = os.path.basename(attachment.file.name)
                except Exception:
                    # In case file.name is not available or causes an error, provide a generic name
                    attachment_names_for_msg[attachment.file.url] = "attachment"
            
            messages.append({
                'message': msg.message,
                'sent_by': str(msg.user.id),
                'send_to': str(other_user.id if msg.user.id == current_user.id else current_user.id),
                'attachment_urls': attachment_urls,
                'attachment_names': attachment_names_for_msg, # Include attachment names
                'timestamp': msg.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'thread_id': str(thread.id),
                'is_encrypted': msg.is_encrypted # Include is_encrypted flag from the model
            })

        # Clean up old messages
        ChatMessage.cleanup_old_messages()

        # Update thread timestamp
        thread.updated = timezone.now()
        thread.save()

        return JsonResponse({
            'success': True,
            'thread_id': str(thread.id),
            'messages': messages,
            'other_user': {
                'id': other_user.id,
                'username': other_user.username,
                'is_online': Presence.is_user_active(other_user)
            }
        })
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'User not found'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

@login_required
def fetch_unread_counts(request):
    current_user_id = request.GET.get('current_user_id')
    
    if not current_user_id:
        return JsonResponse({'error': 'Missing user ID'}, status=400)
        
    try:
        current_user = User.objects.get(id=current_user_id)
        
        # Get all threads involving the current user
        threads = Thread.objects.filter(
            Q(first_person=current_user) | Q(second_person=current_user)
        )
        
        unread_counts = {}
        twenty_four_hours_ago = timezone.now() - timezone.timedelta(hours=24)
        
        for thread in threads:
            # Determine the other user in the thread
            other_user = thread.second_person if thread.first_person == current_user else thread.first_person
            
            # Count unread messages from the other user in the last 24 hours
            unread_count = ChatMessage.objects.filter(
                thread=thread,
                user=other_user,
                timestamp__gte=twenty_four_hours_ago
            ).count()
            
            if unread_count > 0:
                unread_counts[str(other_user.id)] = unread_count
        
        return JsonResponse({
            'unread_counts': unread_counts,
            'success': True
        })
        
    except User.DoesNotExist:
        return JsonResponse({
            'error': 'User not found',
            'success': False
        }, status=404)
    except Exception as e:
        print(f"Error in fetch_unread_counts: {str(e)}")
        return JsonResponse({
            'error': str(e),
            'success': False
        }, status=500)

@login_required
@csrf_exempt
def create_group(request):
    if request.method == 'POST':
        try:
            with transaction.atomic():
                name = request.POST.get('name')
                description = request.POST.get('description', '')  # Get description from POST data
                members = json.loads(request.POST.get('members', '[]'))

                if not name:
                    return JsonResponse({'success': False, 'error': 'Group name is required'})

                if not members:
                    return JsonResponse({'success': False, 'error': 'At least one member is required'})

                # Check if a group with this name already exists
                if Group.objects.filter(name=name).exists():
                    return JsonResponse({
                        'success': False,
                        'error': 'A group with this name already exists'
                    })

                # Create the group with creator_id
                group = Group.objects.create(
                    name=name,
                    description=description,
                    creator=request.user  # Use creator instead of creator_id
                )

                # Add members to the group
                for member_id in members:
                    try:
                        user = User.objects.get(id=member_id)
                        GroupMember.objects.create(
                            group=group,
                            user=user,
                            is_admin=user == request.user
                        )
                    except User.DoesNotExist:
                        continue

                return JsonResponse({
                    'success': True,
                    'group_id': group.id,
                    'message': 'Group created successfully'
                })

        except Exception as e:
            print(f"Error creating group: {str(e)}")  # Debugging line
            return JsonResponse({
                'success': False,
                'error': str(e)
            })

    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def fetch_group_chat_history(request):
    group_id = request.GET.get('group_id')
    
    try:
        group = Group.objects.get(id=group_id)
        if not group.members.filter(id=request.user.id).exists():
            return JsonResponse({'success': False, 'error': 'Not a member of this group'}, status=403)

        messages = GroupMessage.objects.filter(group=group).order_by('created_at')
        
        # Update last read timestamp
        member = GroupMember.objects.get(group=group, user=request.user)
        member.last_read = timezone.now()
        member.save()

        messages_data = []
        for msg in messages:
            messages_data.append({
                'message': msg.message,
                'sent_by': str(msg.sender.id),
                'sender_name': msg.sender.username,
                'thread_id': str(group_id),
                'attachment_urls': msg.attachment_urls or [],
                'attachment_names': msg.attachment_names or {},
                'timestamp': msg.created_at.strftime('%Y-%m-%d %H:%M:%S')
            })

        return JsonResponse({
            'success': True,
            'group_id': group_id,
            'messages': messages_data
        })
    except Group.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Group not found'}, status=404)
    except Exception as e:
        print(f"Error in fetch_group_chat_history: {str(e)}")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

@login_required
def get_group_info(request, group_id):
    try:
        group = Group.objects.get(id=group_id)
        if not group.members.filter(id=request.user.id).exists():
            return JsonResponse({'success': False, 'error': 'Not a member of this group'}, status=403)

        members_data = []
        is_admin = False
        for member in GroupMember.objects.filter(group=group):
            if member.user == request.user:
                is_admin = member.is_admin
            members_data.append({
                'id': member.user.id,
                'username': member.user.username,
                'is_admin': member.is_admin,
                'joined_at': member.joined_at.strftime('%Y-%m-%d %H:%M:%S')
            })

        return JsonResponse({
            'success': True,
            'group_id': group.id,
            'name': group.name,
            'description': group.description,
            'created_by': {
                'id': group.creator.id,
                'username': group.creator.username
            },
            'created_at': group.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'members': members_data,
            'is_admin': is_admin
        })
    except Group.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Group not found'}, status=404)
    except Exception as e:
        print(f"Error in get_group_info: {str(e)}")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

@login_required
@csrf_exempt
def manage_group_members(request, group_id):
    try:
        group = Group.objects.get(id=group_id)
        member = GroupMember.objects.get(group=group, user=request.user)
        
        if not member.is_admin:
            return JsonResponse({'success': False, 'error': 'Only admins can manage members'}, status=403)

        if request.method == 'POST':
            data = json.loads(request.body)
            action = data.get('action')
            user_id = data.get('user_id')
            
            try:
                target_user = User.objects.get(id=user_id)
                target_member = GroupMember.objects.get(group=group, user=target_user)

                if action == 'remove':
                    target_member.delete()
                    group.members.remove(target_user)
                    return JsonResponse({'success': True, 'message': 'Member removed'})
                elif action == 'make_admin':
                    target_member.is_admin = True
                    target_member.save()
                    return JsonResponse({'success': True, 'message': 'Member promoted to admin'})
                elif action == 'remove_admin':
                    if target_user == group.creator:
                        return JsonResponse({'success': False, 'error': 'Cannot remove admin status from group creator'}, status=400)
                    target_member.is_admin = False
                    target_member.save()
                    return JsonResponse({'success': True, 'message': 'Admin status removed'})
                else:
                    return JsonResponse({'success': False, 'error': 'Invalid action'}, status=400)
            except User.DoesNotExist:
                return JsonResponse({'success': False, 'error': 'User not found'}, status=404)
            except GroupMember.DoesNotExist:
                return JsonResponse({'success': False, 'error': 'User is not a member of this group'}, status=404)

        return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)
    except Group.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Group not found'}, status=404)
    except GroupMember.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'You are not a member of this group'}, status=403)
    except Exception as e:
        print(f"Error in manage_group_members: {str(e)}")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)

@login_required
@csrf_exempt
def add_group_members(request, group_id):
    if request.method == 'POST':
        try:
            group = Group.objects.get(id=group_id)
            member = GroupMember.objects.get(group=group, user=request.user)
            
            if not member.is_admin:
                return JsonResponse({'success': False, 'error': 'Only admins can add members'}, status=403)

            data = json.loads(request.body)
            new_member_ids = data.get('member_ids', [])
            
            added_members = []
            for user_id in new_member_ids:
                try:
                    user = User.objects.get(id=user_id)
                    if not group.members.filter(id=user.id).exists():
                        GroupMember.objects.create(group=group, user=user)
                        group.members.add(user)
                        added_members.append({
                            'id': user.id,
                            'username': user.username
                        })
                except User.DoesNotExist:
                    continue

            return JsonResponse({
                'success': True,
                'added_members': added_members
            })
        except Group.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Group not found'}, status=404)
        except GroupMember.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'You are not a member of this group'}, status=403)
        except Exception as e:
            print(f"Error in add_group_members: {str(e)}")
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)

@login_required
def user_status(request):
    try:
        # Get all users except the current user
        users = User.objects.exclude(id=request.user.id)
        users_data = []
        
        for user in users:
            users_data.append({
                'id': user.id,
                'username': user.username,
                'is_online': Presence.is_user_active(user)
            })
        
        return JsonResponse({
            'success': True,
            'users': users_data
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

@require_http_methods(["GET"])
def get_recent_messages(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Unauthorized'}, status=401)
        
    recent_messages = []
    # Get all threads where user is involved
    threads = Thread.objects.filter(
        Q(first_person=request.user) | Q(second_person=request.user)
    )
    
    for thread in threads:
        last_message = ChatMessage.objects.filter(thread=thread).order_by('-timestamp').first()
        if last_message:
            other_user = thread.first_person if thread.first_person != request.user else thread.second_person
            recent_messages.append({
                'thread_id': str(thread.id),
                'other_user_id': str(other_user.id),
                'other_user_name': other_user.username,
                'last_message': last_message.message,
                'timestamp': last_message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'is_read': last_message.is_read
            })
    
    return JsonResponse({
        'recent_messages': sorted(recent_messages, key=lambda x: x['timestamp'], reverse=True)
    })

@require_http_methods(["POST"])
def start_video_call(request):
    try:
        data = json.loads(request.body)
        thread_id = data.get('thread_id')
        group_id = data.get('group_id')
        
        if not thread_id and not group_id:
            return JsonResponse({'error': 'Thread ID or Group ID is required'}, status=400)
        
        if thread_id:
            thread = get_object_or_404(Thread, id=thread_id)
            other_user = thread.first_person if thread.first_person != request.user else thread.second_person
            call = VideoCall.objects.create(
                caller=request.user,
                thread=thread,
                status='pending'
            )
            call.participants.add(request.user, other_user)
        else:
            group = get_object_or_404(Group, id=group_id)
            call = VideoCall.objects.create(
                caller=request.user,
                group=group,
                status='pending'
            )
            call.participants.add(request.user)
            # Add all group members as potential participants
            for member in group.members.all():
                call.participants.add(member)
        
        return JsonResponse({
            'success': True,
            'call_id': str(call.id),
            'is_group_call': bool(group_id)
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

@require_http_methods(["POST"])
def end_video_call(request, call_id):
    try:
        call = get_object_or_404(VideoCall, id=call_id)
        if request.user in call.participants.all():
            call.end_call()
            return JsonResponse({'success': True, 'message': 'Call ended successfully'})
        return JsonResponse({'error': 'You are not a participant in this call'}, status=403)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

@login_required
def group_members(request, group_id):
    group = get_object_or_404(Group, id=group_id)
    members = GroupMember.objects.filter(group=group).select_related('user')
    is_admin = GroupMember.objects.filter(group=group, user=request.user, is_admin=True).exists()
    
    context = {
        'group': group,
        'members': members,
        'is_admin': is_admin,
        'current_user': request.user
    }
    return render(request, 'group_members.html', context)

@login_required
def leave_group(request, group_id):
    if request.method == 'POST':
        group = get_object_or_404(Group, id=group_id)
        group_member = get_object_or_404(GroupMember, group=group, user=request.user)
        
        # Only block if the user is the last admin
        if group_member.is_admin:
            admin_count = GroupMember.objects.filter(group=group, is_admin=True).count()
            if admin_count == 1:
                return JsonResponse({
                    'success': False,
                    'message': 'Cannot leave group as you are the last admin. Please assign another admin first.'
                })
        
        group_member.delete()
        return JsonResponse({
            'success': True,
            'message': 'Successfully left the group'
        })
    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=400)

@login_required
def delete_group(request, group_id):
    if request.method == 'POST':
        group = get_object_or_404(Group, id=group_id)
        
        # Authorization: Only the group creator can delete the group
        if request.user != group.creator:
            return JsonResponse({
                'success': False,
                'error': 'You do not have permission to delete this group.'
            }, status=403) # Forbidden
            
        try:
            group.delete()
            return JsonResponse({
                'success': True,
                'message': 'Group deleted successfully.'
            })
        except Exception as e:
            # Log the error for debugging
            print(f"Error deleting group {group_id}: {str(e)}") 
            return JsonResponse({
                'success': False,
                'error': 'An unexpected error occurred while deleting the group.'
            }, status=500)
            
    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=400)

@login_required
def create_video_call_room(request, group_id):
    group = get_object_or_404(Group, id=group_id)
    
    # Check if user is a member of the group
    if not group.members.filter(id=request.user.id).exists():
        return JsonResponse({'error': 'You are not a member of this group'}, status=403)
    
    # Generate a unique room name
    room_name = f"group_{group_id}_{uuid.uuid4().hex[:8]}"
    
    # Create the video call room
    room = VideoCallRoom.objects.create(
        group=group,
        room_name=room_name,
        created_by=request.user
    )
    
    return JsonResponse({
        'room_name': room_name,
        'room_id': room.id
    })

@login_required
def join_video_call_room(request, room_name):
    room = get_object_or_404(VideoCallRoom, room_name=room_name)
    
    # Check if user is a member of the group
    if not room.group.members.filter(id=request.user.id).exists():
        return JsonResponse({'error': 'You are not a member of this group'}, status=403)
    
    # Get current participants
    participants = VideoCallParticipant.objects.filter(room=room, is_active=True)
    participant_data = [{
        'user_id': str(p.user.id),
        'username': p.user.username,
        'stream_id': p.stream_id
    } for p in participants]
    
    return JsonResponse({
        'room_name': room_name,
        'participants': participant_data
    })

@login_required
def leave_video_call_room(request, room_name):
    room = get_object_or_404(VideoCallRoom, room_name=room_name)
    
    # Remove participant
    VideoCallParticipant.objects.filter(
        room=room,
        user=request.user
    ).delete()
    
    return JsonResponse({'status': 'success'})

@login_required
def end_video_call_room(request, room_name):
    room = get_object_or_404(VideoCallRoom, room_name=room_name)
    
    # Check if user is the creator or an admin
    if room.created_by != request.user and not room.group.groupmember_set.filter(user=request.user, is_admin=True).exists():
        return JsonResponse({'error': 'You do not have permission to end this call'}, status=403)
    
    # Mark room as inactive
    room.is_active = False
    room.save()
    
    # Remove all participants
    VideoCallParticipant.objects.filter(room=room).delete()
    
    return JsonResponse({'status': 'success'})

@login_required
@csrf_exempt
def update_profile(request):
    if request.method == 'POST':
        user = request.user
        username = request.POST.get('username')
        profile_pic = request.FILES.get('profile_pic')

        if username:
            user.username = username
            user.save()

        profile, created = UserProfile.objects.get_or_create(user=user)
        if profile_pic:
            profile.profile_pic = profile_pic
            profile.save()

        profile_pic_url = profile.profile_pic.url if profile.profile_pic else '/static/img/default-avatar.svg'
        return JsonResponse({'success': True, 'profile_pic_url': profile_pic_url})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})

@login_required
def custom_admin_dashboard(request):
    """
    Custom admin dashboard view with modern UI but same information as Django admin
    """
    if not request.user.is_staff:
        return redirect('home')
    
    # Get all registered models from admin site
    from django.contrib.admin import site
    from django.contrib.admin.models import LogEntry
    from django.contrib.contenttypes.models import ContentType
    import django
    
    # Build app list similar to Django admin
    app_list = site._build_app_dict(request)
    
    # Get recent actions (same as in Django admin)
    log_entries = LogEntry.objects.select_related('content_type', 'user')[:10]
    
    # Add additional stats
    total_users = User.objects.count()
    total_groups = Group.objects.count()
    total_threads = Thread.objects.count()
    total_messages = ChatMessage.objects.count()
    
    # User activity stats
    last_24h = timezone.now() - timezone.timedelta(hours=24)
    active_users_24h = Presence.objects.filter(
        last_seen__gte=last_24h
    ).values('user').distinct().count()
    
    # New messages in the last 24 hours
    new_messages_24h = ChatMessage.objects.filter(timestamp__gte=last_24h).count()
    
    # New groups in the last 24 hours
    new_groups_24h = Group.objects.filter(created_at__gte=last_24h).count()
    
    # Active threads (threads with messages in the last 24 hours)
    active_threads = Thread.objects.filter(
        chatmessage__timestamp__gte=last_24h
    ).distinct().count()
    
    # Message stats by day (last 7 days)
    last_week = timezone.now() - timezone.timedelta(days=7)
    messages_by_day = ChatMessage.objects.filter(
        timestamp__gte=last_week
    ).extra(
        select={'day': 'date(timestamp)'}
    ).values('day').annotate(count=models.Count('id')).order_by('day')
    
    # Convert QuerySet to list for JSON serialization
    messages_by_day_list = list(messages_by_day)
    for item in messages_by_day_list:
        item['day'] = item['day'].strftime('%Y-%m-%d')
    
    # Recent Communications (both group and direct) with most recent activity
    recent_threads = Thread.objects.filter(
        chatmessage__timestamp__isnull=False
    ).annotate(
        last_message_time=models.Max('chatmessage__timestamp'),
        message_count=models.Count('chatmessage')
    ).order_by('-last_message_time')[:10]
    
    recent_group_messages = ChatMessage.objects.filter(
        group__isnull=False
    ).select_related('group').values(
        'group'
    ).annotate(
        last_message_time=models.Max('timestamp'),
        message_count=models.Count('id')
    ).order_by('-last_message_time')[:10]
    
    # Combine and sort recent communications
    recent_communications = []
    
    # Process threads (direct messages)
    for thread in recent_threads:
        last_message = ChatMessage.objects.filter(thread=thread).order_by('-timestamp').first()
        last_message_content = last_message.message if last_message else "No messages"
        
        # Get user profiles
        try:
            user1_profile = UserProfile.objects.get(user=thread.first_person)
            user1_pic = user1_profile.profile_pic.url if user1_profile.profile_pic else '/static/img/default-avatar.svg'
        except UserProfile.DoesNotExist:
            user1_pic = '/static/img/default-avatar.svg'
        
        try:
            user2_profile = UserProfile.objects.get(user=thread.second_person)
            user2_pic = user2_profile.profile_pic.url if user2_profile.profile_pic else '/static/img/default-avatar.svg'
        except UserProfile.DoesNotExist:
            user2_pic = '/static/img/default-avatar.svg'
        
        recent_communications.append({
            'is_group': False,
            'user1': thread.first_person.username,
            'user2': thread.second_person.username,
            'user1_pic': user1_pic,
            'user2_pic': user2_pic,
            'message_count': thread.message_count,
            'last_activity': thread.last_message_time,
            'last_message': last_message_content,
            'thread_id': thread.id
        })
    
    # Process group messages
    for group_data in recent_group_messages:
        group = Group.objects.get(id=group_data['group'])
        last_message = ChatMessage.objects.filter(group=group).order_by('-timestamp').first()
        last_message_content = last_message.message if last_message else "No messages"
        
        recent_communications.append({
            'is_group': True,
            'group_name': group.name,
            'message_count': group_data['message_count'],
            'last_activity': group_data['last_message_time'],
            'last_message': last_message_content,
            'group_id': group.id
        })
    
    # Sort all communications by last activity
    recent_communications.sort(key=lambda x: x['last_activity'], reverse=True)
    
    # Get new messages for display
    new_messages = []
    recent_messages = ChatMessage.objects.filter(
        timestamp__gte=last_24h
    ).select_related('user', 'thread', 'group').order_by('-timestamp')[:15]
    
    for message in recent_messages:
        # Get user profile pic
        try:
            profile = UserProfile.objects.get(user=message.user)
            user_pic = profile.profile_pic.url if profile.profile_pic else '/static/img/default-avatar.svg'
        except UserProfile.DoesNotExist:
            user_pic = '/static/img/default-avatar.svg'
        
        # Determine recipient (user or group)
        if message.group:
            is_group = True
            recipient = message.group.name
        else:
            is_group = False
            recipient_user = message.thread.second_person if message.user == message.thread.first_person else message.thread.first_person
            recipient = recipient_user.username
        
        new_messages.append({
            'user': message.user.username,
            'user_pic': user_pic,
            'content': message.message[:100] + ('...' if len(message.message) > 100 else ''),
            'has_attachment': message.attachment.name != '',
            'is_group': is_group,
            'recipient': recipient,
            'time': message.timestamp
        })
    
    # System Information
    try:
        # Estimate number of active WebSocket connections
        from channels.layers import get_channel_layer
        from asgiref.sync import async_to_sync
        channel_layer = get_channel_layer()
        # This is just an approximation - in reality we would need to count active connections
        active_websockets = Presence.objects.filter(last_seen__gte=timezone.now() - timezone.timedelta(minutes=5)).count()
    except:
        active_websockets = 0
    
    # Database connections
    from django.db import connections
    db_connections = len(connections.all())
    
    context = {
        'title': 'Admin Dashboard',
        'app_list': app_list,
        'log_entries': log_entries,
        'user': request.user,
        'stats': {
            'total_users': total_users,
            'total_groups': total_groups,
            'total_threads': total_threads,
            'total_messages': total_messages,
            'active_users_24h': active_users_24h,
        },
        'new_messages_24h': new_messages_24h,
        'new_groups_24h': new_groups_24h,
        'active_threads': active_threads,
        'messages_by_day': messages_by_day_list,
        'recent_communications': recent_communications[:10],
        'new_messages': new_messages,
        'django_version': django.get_version(),
        'server_time': timezone.now(),
        'db_connections': db_connections,
        'active_websockets': active_websockets,
    }
    
    return render(request, 'admin/dashboard.html', context)

@login_required
@superuser_required
def admin_user_management(request):
    """
    Admin page for user management - allows viewing, searching, and managing user accounts
    """
    if not request.user.is_staff:
        return redirect('home')
    
    # Get query parameters for filtering
    search_query = request.GET.get('search', '')
    status_filter = request.GET.get('status', 'all')
    
    # Start with all users
    users = User.objects.all().order_by('-date_joined')
    
    # Apply search filter if provided
    if search_query:
        users = users.filter(
            Q(username__icontains=search_query) | 
            Q(email__icontains=search_query)
        )
    
    # Apply status filter if provided
    if status_filter == 'active':
        active_user_ids = Presence.get_active_users().values_list('id', flat=True)
        users = users.filter(id__in=active_user_ids)
    elif status_filter == 'inactive':
        active_user_ids = Presence.get_active_users().values_list('id', flat=True)
        users = users.exclude(id__in=active_user_ids)
    
    # Add additional user stats
    users_with_stats = []
    for user in users:
        # Count messages sent
        message_count = ChatMessage.objects.filter(user=user).count()
        
        # Count groups
        group_count = GroupMember.objects.filter(user=user).count()
        
        # Get last login time
        last_login = user.last_login
        
        # Check if user is active recently
        is_active = Presence.is_user_active(user)
        
        # Get profile picture if available
        try:
            profile = UserProfile.objects.get(user=user)
            profile_pic = profile.profile_pic.url if profile.profile_pic else '/static/img/default-avatar.svg'
        except:
            profile_pic = '/static/img/default-avatar.svg'
        
        users_with_stats.append({
            'user': user,
            'message_count': message_count,
            'group_count': group_count,
            'last_login': last_login,
            'is_active': is_active,
            'profile_pic': profile_pic
        })
    
    context = {
        'title': 'User Management',
        'users': users_with_stats,
        'search_query': search_query,
        'status_filter': status_filter,
        'user_count': User.objects.count(),
        'active_count': Presence.get_active_users().count(),
    }
    
    return render(request, 'admin/user_management.html', context)