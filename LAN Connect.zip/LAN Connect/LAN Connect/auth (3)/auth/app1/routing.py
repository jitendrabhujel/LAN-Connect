from django.urls import path
from . import consumers 

websocket_urlpatterns = [
    path('home/', consumers.ChatConsumer.as_asgi()),
    path('ws/video-call/<str:room_name>/', consumers.VideoCallConsumer.as_asgi()),
]