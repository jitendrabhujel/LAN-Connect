from django.urls import path
from . import views
from .views import get_recent_messages, start_video_call, end_video_call, update_profile

urlpatterns = [
    path('', views.home_page, name='home'),
    path('signup/', views.signup_page, name='signup'),
    path('login/', views.login_page, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('fetch_chat_history/', views.fetch_chat_history, name='fetch_chat_history'),
    path('create_group/', views.create_group, name='create_group'),
    path('fetch_group_chat_history/', views.fetch_group_chat_history, name='fetch_group_chat_history'),
    path('get_group_info/<int:group_id>/', views.get_group_info, name='get_group_info'),
    path('manage_group_members/<int:group_id>/', views.manage_group_members, name='manage_group_members'),
    path('add_group_members/<int:group_id>/', views.add_group_members, name='add_group_members'),
    path('messages/', views.messages_page, name='messages'),
    path('video-call/<str:call_id>/', views.video_call, name='video_call'),
    path('video-call/<str:call_id>/group/<int:group_id>/', views.video_call, name='group_video_call'),
    path('video-call/start/', views.start_video_call, name='start_video_call'),
    path('video-call/end/<str:call_id>/', views.end_video_call, name='end_video_call'),
    path('fetch_unread_counts/', views.fetch_unread_counts, name='fetch_unread_counts'),
    path('user_status/', views.user_status, name='user_status'),
    path('recent-messages/', get_recent_messages, name='recent_messages'),
    path('group/<int:group_id>/members/', views.group_members, name='group_members'),
    path('leave_group/<int:group_id>/', views.leave_group, name='leave_group'),
    path('delete_group/<int:group_id>/', views.delete_group, name='delete_group'),
    
    # Video call room management URLs
    path('video-call/room/create/<int:group_id>/', views.create_video_call_room, name='create_video_call_room'),
    path('video-call/room/join/<str:room_name>/', views.join_video_call_room, name='join_video_call_room'),
    path('video-call/room/leave/<str:room_name>/', views.leave_video_call_room, name='leave_video_call_room'),
    path('video-call/room/end/<str:room_name>/', views.end_video_call_room, name='end_video_call_room'),
    path('update_profile/', update_profile, name='update_profile'),
    
    # Custom admin dashboard
    path('admin-dashboard/', views.custom_admin_dashboard, name='custom_admin_dashboard'),
    path('admin-users/', views.admin_user_management, name='admin_user_management'),
]