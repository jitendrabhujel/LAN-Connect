$(document).ready(function() {
    const loginForm = $('#login-form');
    const usernameInput = $('#username');
    const passwordInput = $('#password');
    const errorDisplay = $('#error-message');

    function showAlert(type, message, isDismissible = true) {
        let alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        let alertHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert" 
                 style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 9999; min-width: 300px; 
                        background-color: #fff; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px;">
                <div style="display: flex; align-items: start; justify-content: space-between; gap: 10px;">
                    <div>
                        ${type === 'error' ? '❌' : '✅'} 
                        <span style="margin-left: 8px;">${message}</span>
                    </div>
                    <button type="button" class="close" style="font-size: 1.5rem; font-weight: 700; line-height: 1; 
                            color: #000; text-shadow: 0 1px 0 #fff; opacity: .5; background: none; border: none; 
                            padding: 0; cursor: pointer;" onclick="this.parentElement.parentElement.remove();">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>`;

        // Remove any existing alerts
        $('.alert').remove();
        
        // Add new alert to body
        $('body').append(alertHtml);

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            $('.alert').fadeOut(300, function() { $(this).remove(); });
        }, 5000);
    }

    function showError(message) {
        showAlert('error', ValidationUtils.sanitizeInput(message));
    }

    function hideError() {
        $('.alert').remove();
    }

    // Real-time validation
    usernameInput.on('input', function() {
        const username = $(this).val().trim();
        if (username && !ValidationUtils.isValidUsername(username)) {
            $(this).addClass('is-invalid');
            showError(ValidationUtils.getValidationMessage('username', 'invalid'));
        } else {
            $(this).removeClass('is-invalid');
            hideError();
        }
    });

    loginForm.on('submit', function(e) {
        e.preventDefault();
        hideError();

        const username = ValidationUtils.sanitizeInput(usernameInput.val().trim());
        const password = passwordInput.val(); // Don't sanitize password before sending

        // Validate inputs
        if (!username) {
            showError(ValidationUtils.getValidationMessage('username', 'required'));
            return;
        }

        if (!password) {
            showError(ValidationUtils.getValidationMessage('password', 'required'));
            return;
        }

        if (!ValidationUtils.isValidUsername(username)) {
            showError(ValidationUtils.getValidationMessage('username', 'invalid'));
            return;
        }

        // Send login request
        $.ajax({
            url: '/login/',
            method: 'POST',
            data: {
                username: username,
                password: password
            },
            headers: {
                'X-CSRFToken': ValidationUtils.getCsrfToken()
            },
            success: function(response) {
                if (response.success) {
                    // Generate RSA key pair on first login
                    generateAndStoreKeys(username).then(() => {
                    showAlert('success', 'Logged in successfully!');
                    setTimeout(() => {
                        window.location.href = response.redirect_url || '/';
                    }, 1500);
                    }).catch(error => {
                        console.error('Key generation failed:', error);
                        showError('Key generation failed. Please try again.');
                    });
                } else {
                    showError(response.error || 'Login failed. Please try again.');
                }
            },
            error: function() {
                showError('An error occurred. Please try again later.');
            }
        });
    });

    // Clear error on input focus
    $('input').on('focus', function() {
        hideError();
        $(this).removeClass('is-invalid');
    });
}); 

async function generateAndStoreKeys(username) {
    try {
        // Generate RSA key pair
        const keyPair = await window.crypto.subtle.generateKey(
            {
                name: "RSA-OAEP",
                modulusLength: 2048,
                publicExponent: new Uint8Array([1, 0, 1]),
                hash: "SHA-256",
            },
            true,
            ["encrypt", "decrypt"]
        );

        // Export public key
        const publicKey = await window.crypto.subtle.exportKey(
            "spki",
            keyPair.publicKey
        );

        // Convert public key to base64
        const publicKeyBase64 = btoa(String.fromCharCode(...new Uint8Array(publicKey)));

        // Store private key in IndexedDB
        const privateKey = await window.crypto.subtle.exportKey(
            "pkcs8",
            keyPair.privateKey
        );
        
        // Store keys in IndexedDB
        await storeKeysInIndexedDB(username, privateKey, publicKeyBase64);

        // Send public key to server
        await sendPublicKeyToServer(username, publicKeyBase64);

    } catch (error) {
        console.error('Error generating or storing keys:', error);
        throw error;
    }
}

async function storeKeysInIndexedDB(username, privateKey, publicKey) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('ChatKeysDB', 1);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
            const db = request.result;
            const transaction = db.transaction(['keys'], 'readwrite');
            const store = transaction.objectStore('keys');
            
            const keyData = {
                username: username,
                privateKey: privateKey,
                publicKey: publicKey,
                timestamp: new Date().getTime()
            };

            const putRequest = store.put(keyData);
            
            putRequest.onsuccess = () => resolve();
            putRequest.onerror = () => reject(putRequest.error);
        };

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains('keys')) {
                db.createObjectStore('keys', { keyPath: 'username' });
            }
        };
    });
}

async function sendPublicKeyToServer(username, publicKey) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: '/store-public-key/',
            method: 'POST',
            data: {
                username: username,
                public_key: publicKey
            },
            headers: {
                'X-CSRFToken': ValidationUtils.getCsrfToken()
            },
            success: function(response) {
                if (response.success) {
                    resolve();
                } else {
                    reject(new Error(response.error || 'Failed to store public key'));
                }
            },
            error: function(xhr, status, error) {
                reject(new Error('Failed to send public key to server'));
            }
        });
    });
} 