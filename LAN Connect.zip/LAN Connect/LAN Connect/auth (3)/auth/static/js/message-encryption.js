/**
 * Message Encryption Module for One-to-One Chat
 * Uses AES-256 encryption via CryptoJS
 */

let currentLocalUserId = null; // Will be set by initEncryptionModule

function initEncryptionModule(userId) {
    currentLocalUserId = userId;
    console.log('[Encryption-AES] Module initialized with User ID:', currentLocalUserId);
}

const encryptionKeys = {}; // Store encryption keys (as WordArrays) by pair identifier

function getEncryptionKey(otherUserId) {
    const currentLoggedInUserId = currentLocalUserId;
    if (!otherUserId) {
        console.error("[Encryption-AES] getEncryptionKey called with undefined otherUserId");
        return null;
    }
    if (!currentLoggedInUserId) {
        console.error("[Encryption-AES] getEncryptionKey: currentLoggedInUserId is not defined.");
        return null;
    }

    let pairIdentifier = String(currentLoggedInUserId) < String(otherUserId) ? `${currentLoggedInUserId}_${otherUserId}` : `${otherUserId}_${currentLoggedInUserId}`;
    let keyStorageName = `encryption_key_aes_pair_${pairIdentifier}`;

    if (encryptionKeys[pairIdentifier]) {
        console.log(`[Encryption-AES] Using CACHED IN MEMORY PAIRED key (WordArray) for ${pairIdentifier}. Key (hex): ${encryptionKeys[pairIdentifier].toString(CryptoJS.enc.Hex).substring(0,16)}...`);
    } else {
        console.log(`[Encryption-AES] Key for ${pairIdentifier} NOT in memory cache. Trying localStorage...`);
        let storedKey_b64 = localStorage.getItem(keyStorageName);
        if (storedKey_b64) {
            try {
                const parsedKey = CryptoJS.enc.Base64.parse(storedKey_b64);
                encryptionKeys[pairIdentifier] = parsedKey;
                console.log(`[Encryption-AES] Loaded PAIRED key for ${pairIdentifier} FROM LOCALSTORAGE. Key (hex): ${parsedKey.toString(CryptoJS.enc.Hex).substring(0,16)}...`);
            } catch (e) {
                console.error(`[Encryption-AES] Failed to parse stored key for ${pairIdentifier} from Base64. Removing problematic key.`, e);
                localStorage.removeItem(keyStorageName); // Remove bad key
                // Force generation next
            }
        }

        if (!encryptionKeys[pairIdentifier]) { // If still not in cache (not in LS or parsing failed)
            console.log(`[Encryption-AES] Key for ${pairIdentifier} NOT in localStorage or parsing failed. GENERATING NEW (derived) KEY.`);
            // Derive key from pairIdentifier for deterministic generation
            const newKeyMaterial = CryptoJS.SHA256(pairIdentifier);
            encryptionKeys[pairIdentifier] = newKeyMaterial;
            localStorage.setItem(keyStorageName, CryptoJS.enc.Base64.stringify(newKeyMaterial));
            console.log(`[Encryption-AES] Generated/Derived NEW PAIRED key for ${pairIdentifier} using SHA256(pairIdentifier). Key (hex): ${newKeyMaterial.toString(CryptoJS.enc.Hex).substring(0,16)}... Stored as Base64.`);
        }
    }
    return encryptionKeys[pairIdentifier];
}

function encryptMessage(message, otherUserId) {
    if (!message || !otherUserId) {
        console.error("[Encryption-AES] encryptMessage: Message or otherUserId is missing.");
        return message;
    }
    console.log(`[Encryption-AES] Plaintext to encrypt for ${otherUserId}: "${message}"`);

    const key_wordArray = getEncryptionKey(otherUserId);
    if (!key_wordArray) {
        console.error(`[Encryption-AES] encryptMessage: Could not get PAIRED key for ${otherUserId}. Returning plaintext.`);
        return message;
    }

    const iv = CryptoJS.lib.WordArray.random(128 / 8);
    console.log(`[Encryption-AES] Encrypting for ${otherUserId}. Key (hex): ${key_wordArray.toString(CryptoJS.enc.Hex).substring(0,16)}..., IV (hex): ${iv.toString(CryptoJS.enc.Hex)}`);

    const encrypted = CryptoJS.AES.encrypt(message, key_wordArray, { iv: iv });
    const iv_b64 = CryptoJS.enc.Base64.stringify(iv);
    const ciphertext_b64 = CryptoJS.enc.Base64.stringify(encrypted.ciphertext);

    console.log(`[Encryption-AES] Encrypt: IV (b64): ${iv_b64}, Ciphertext (b64): ${ciphertext_b64.substring(0,30)}...`);
    const fullEncryptedString = `encrypted-aes:${iv_b64}:${ciphertext_b64}`;
    console.log(`[Encryption-AES] Full encrypted string being returned: "${fullEncryptedString}"`);
    return fullEncryptedString;
}

function decryptMessage(encryptedMessage, senderUserId) {
    console.log(`[Encryption-AES] Attempting to decrypt from sender ${senderUserId}, message: "${encryptedMessage ? encryptedMessage.substring(0, 70) : 'EMPTY MESSAGE'}..."`);
    if (!encryptedMessage || !senderUserId) {
        console.error("[Encryption-AES] decryptMessage: Encrypted message or senderUserId is missing.");
        return encryptedMessage;
    }
    if (typeof encryptedMessage !== 'string') {
        console.error(`[Encryption-AES] decryptMessage: encryptedMessage is not a string. Type: ${typeof encryptedMessage}.`);
        return encryptedMessage;
    }

    const prefix = 'encrypted-aes:';
    if (!encryptedMessage.startsWith(prefix)) {
        console.warn(`[Encryption-AES] decryptMessage: Message for ${senderUserId} lacks '${prefix}' prefix. Msg: "${encryptedMessage.substring(0, 70)}..."`);
        return encryptedMessage;
    }

    const parts = encryptedMessage.substring(prefix.length).split(':');
    if (parts.length !== 2) {
        console.error(`[Encryption-AES] decryptMessage: Malformed message for ${senderUserId}. Expected 2 parts, got ${parts.length}.`);
        return '[Encrypted message - AES format error]';
    }

    const iv_b64 = parts[0];
    const ciphertext_b64 = parts[1];
    const key_wordArray = getEncryptionKey(senderUserId);

    if (!key_wordArray) {
        console.error(`[Encryption-AES] decryptMessage: No key for ${senderUserId}.`);
        return '[Encrypted message - AES key unavailable]';
    }

    try {
        const iv_wordArray = CryptoJS.enc.Base64.parse(iv_b64);
        const ciphertext_wordArray = CryptoJS.enc.Base64.parse(ciphertext_b64);
        
        console.log(`[Encryption-AES] Decrypting from ${senderUserId}. Key (hex): ${key_wordArray.toString(CryptoJS.enc.Hex).substring(0,16)}..., IV (hex from msg): ${iv_wordArray.toString(CryptoJS.enc.Hex)}`);

        const decrypted = CryptoJS.AES.decrypt({ ciphertext: ciphertext_wordArray }, key_wordArray, { iv: iv_wordArray });
        
        console.log(`[Encryption-AES] Decryption WordArray (hex): ${decrypted.toString(CryptoJS.enc.Hex).substring(0,32)}..., sigBytes: ${decrypted.sigBytes}`);

        let decryptedText = "";
        if (decrypted && decrypted.sigBytes > 0) {
            try {
                decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
            } catch (utf8Error) {
                console.error(`[Encryption-AES] UTF-8 conversion error for ${senderUserId}:`, utf8Error);
                console.warn(`[Encryption-AES] Decrypted data (hex) that failed UTF-8: ${decrypted.toString(CryptoJS.enc.Hex)}`);
                return '[Encrypted message - AES malformed UTF-8 data]';
            }
        } else if (ciphertext_wordArray.sigBytes > 0) {
             console.warn(`[Encryption-AES] Decryption for ${senderUserId} empty (0 sigBytes) from non-empty ciphertext. Key/IV mismatch?`);
             return '[Encrypted message - AES decryption empty result]';
        }

        console.log(`[Encryption-AES] Successfully decrypted from ${senderUserId}. Plaintext: "${decryptedText.substring(0,100)}${decryptedText.length > 100 ? '...' : ''}"`);
        return decryptedText;

    } catch (error) {
        console.error(`[Encryption-AES] General decryption error for ${senderUserId}:`, error);
        console.error(`[Encryption-AES] Details - Key (hex): ${key_wordArray.toString(CryptoJS.enc.Hex).substring(0,16)}..., IV (b64 from msg): ${iv_b64}`);
        return '[Encrypted message - AES decryption failed]';
    }
}

function isEncryptionEnabledForUser(otherUserId) {
    if (!otherUserId) return false;
    return localStorage.getItem(`encryption_enabled_${otherUserId}`) === 'true';
}

function setEncryptionEnabled(otherUserId, enabled) {
    if (!otherUserId) return;
    localStorage.setItem(`encryption_enabled_${otherUserId}`, enabled ? 'true' : 'false');
    if (enabled) {
        getEncryptionKey(otherUserId);
    }
}

// No need for DOMContentLoaded listener for loadEncryptionKeys as it's handled on demand.
// However, ensure initEncryptionModule is called correctly in home.js when USER_ID is available. 