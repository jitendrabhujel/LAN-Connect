// File upload handling
function handleFileUpload(files, targetUserId) {
    Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const fileData = e.target.result;
            socket.send(JSON.stringify({
                type: file.type.startsWith('image/') ? 'image_transfer' : 'file_transfer',
                target_user_id: targetUserId,
                file_data: fileData,
                file_name: file.name,
                file_type: file.type
            }));

            // Show upload progress indicator
            showUploadProgress(file.name);
        };
        reader.readAsDataURL(file);
    });
}

// Show upload progress
function showUploadProgress(fileName) {
    const progressHtml = `
        <div class="upload-progress" data-file="${fileName}">
            <div class="progress-text">Uploading ${fileName}...</div>
            <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                     role="progressbar" style="width: 100%"></div>
            </div>
        </div>
    `;
    $('.msg_card_body').append(progressHtml);
    scrollToBottom();
}

// Handle successful file transfer
function handleFileTransferSuccess(data) {
    // Remove progress indicator
    $(`.upload-progress[data-file="${data.file_name}"]`).remove();
    
    // Add file message
    const fileHtml = createFileMessage(data.file_url, data.file_name, true);
    $('.msg_card_body').append(fileHtml);
    scrollToBottom();
}

// Handle received file
function handleFileReceived(data) {
    const fileHtml = createFileMessage(data.file_url, data.file_name, false, data.sender_name);
    $('.msg_card_body').append(fileHtml);
    scrollToBottom();
    
    // Play notification sound
    playNotificationSound();
}

// Handle successful image transfer
function handleImageTransferSuccess(data) {
    // Remove progress indicator
    $(`.upload-progress[data-file="${data.image_name}"]`).remove();
    
    // Add image message
    const imageHtml = createImageMessage(data.image_url, data.image_name, true);
    $('.msg_card_body').append(imageHtml);
    scrollToBottom();
}

// Handle received image
function handleImageReceived(data) {
    const imageHtml = createImageMessage(data.image_url, data.image_name, false, data.sender_name);
    $('.msg_card_body').append(imageHtml);
    scrollToBottom();
    
    // Play notification sound
    playNotificationSound();
}

// Create file message HTML
function createFileMessage(fileUrl, fileName, isSender, senderName = '') {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const fileIcon = getFileIcon(fileName);
    
    return `
        <div class="d-flex mb-4 ${isSender ? 'justify-content-end' : 'justify-content-start'}">
            <div class="msg_cotainer${isSender ? '_send' : ''}">
                ${!isSender ? `<div class="msg_sender">${senderName}</div>` : ''}
                <div class="file-message">
                    <i class="${fileIcon} file-icon"></i>
                    <a href="${fileUrl}" target="_blank" class="file-link">
                        ${fileName}
                    </a>
                </div>
                <span class="msg_time${isSender ? '_send' : ''}">${time}</span>
            </div>
        </div>
    `;
}

// Create image message HTML
function createImageMessage(imageUrl, imageName, isSender, senderName = '') {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    return `
        <div class="d-flex mb-4 ${isSender ? 'justify-content-end' : 'justify-content-start'}">
            <div class="msg_cotainer${isSender ? '_send' : ''}">
                ${!isSender ? `<div class="msg_sender">${senderName}</div>` : ''}
                <div class="image-message">
                    <img src="${imageUrl}" alt="${imageName}" class="chat-image" 
                         onclick="openImageViewer('${imageUrl}')">
                </div>
                <span class="msg_time${isSender ? '_send' : ''}">${time}</span>
            </div>
        </div>
    `;
}

// Get appropriate file icon based on file type
function getFileIcon(fileName) {
    const ext = fileName.split('.').pop().toLowerCase();
    const iconMap = {
        'pdf': 'fas fa-file-pdf',
        'doc': 'fas fa-file-word',
        'docx': 'fas fa-file-word',
        'xls': 'fas fa-file-excel',
        'xlsx': 'fas fa-file-excel',
        'zip': 'fas fa-file-archive',
        'rar': 'fas fa-file-archive',
        'txt': 'fas fa-file-alt',
        'mp3': 'fas fa-file-audio',
        'mp4': 'fas fa-file-video'
    };
    return iconMap[ext] || 'fas fa-file';
}

// Image viewer
function openImageViewer(imageUrl) {
    const viewer = `
        <div class="image-viewer" onclick="closeImageViewer()">
            <img src="${imageUrl}" alt="Full size image">
            <div class="close-viewer">&times;</div>
        </div>
    `;
    $('body').append(viewer);
}

function closeImageViewer() {
    $('.image-viewer').remove();
}

// Add to your existing WebSocket message handler
socket.onmessage = function(e) {
    const data = JSON.parse(e.data);
    
    switch(data.type) {
        case 'file_transfer_success':
            handleFileTransferSuccess(data);
            break;
        case 'file_received':
            handleFileReceived(data);
            break;
        case 'image_transfer_success':
            handleImageTransferSuccess(data);
            break;
        case 'image_received':
            handleImageReceived(data);
            break;
        case 'file_transfer_error':
            alert('Error uploading file: ' + data.message);
            $(`.upload-progress[data-file="${data.file_name}"]`).remove();
            break;
        // ... handle other message types ...
    }
};

// File input change handler
$('#file_input').on('change', function(e) {
    const files = e.target.files;
    const targetUserId = $('.active-chat').attr('user-id');
    if (files.length > 0 && targetUserId) {
        handleFileUpload(files, targetUserId);
    }
    // Clear the input
    $(this).val('');
});

// Drag and drop handling
$('.msg_card_body').on('dragover', function(e) {
    e.preventDefault();
    $(this).addClass('drag-over');
});

$('.msg_card_body').on('dragleave', function(e) {
    e.preventDefault();
    $(this).removeClass('drag-over');
});

$('.msg_card_body').on('drop', function(e) {
    e.preventDefault();
    $(this).removeClass('drag-over');
    
    const files = e.originalEvent.dataTransfer.files;
    const targetUserId = $('.active-chat').attr('user-id');
    if (files.length > 0 && targetUserId) {
        handleFileUpload(files, targetUserId);
    }
});

class ChatManager {
    constructor() {
        this.socket = null;
        this.messageCallbacks = new Set();
    }

    connect() {
        this.socket = new WebSocket(`ws://${window.location.host}/ws/chat/`);
        
        this.socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
        };

        this.socket.onclose = () => {
            console.log('Chat socket closed unexpectedly');
            // Try to reconnect in 5 seconds
            setTimeout(() => this.connect(), 5000);
        };
    }

    handleMessage(data) {
        // Notify all registered callbacks
        this.messageCallbacks.forEach(callback => callback(data));
    }

    sendMessage(targetUserId, message) {
        if (this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify({
                type: 'text_message',
                target_user_id: targetUserId,
                message: message
            }));
        } else {
            console.error('WebSocket is not connected');
        }
    }

    // Register callback for message events
    onMessage(callback) {
        this.messageCallbacks.add(callback);
        return () => this.messageCallbacks.delete(callback);
    }
}

// Create and export singleton instance
const chatManager = new ChatManager();
export default chatManager; 