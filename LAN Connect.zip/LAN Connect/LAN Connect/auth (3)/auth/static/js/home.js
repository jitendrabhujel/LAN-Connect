// home.js
function getProperUrl(url) {
    // Assuming the URL from the server is already correct (e.g., /media/... or full https://...)
    // If it's a relative path like 'chat_attachments/images/file.png' 
    // and doesn't start with /media/, you might need to prepend settings.MEDIA_URL conceptually.
    // For now, let's assume it's either absolute or correctly relative to the domain root.
    // A more robust solution would check if it's an absolute URL or needs prefixing.
    if (url && (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('/'))) {
        return url; // Already absolute or root-relative
    }
    // If it's something like 'chat_attachments/images/file.png' (relative to media root but without /media/)
    // this is a common case if server returns just the path after MEDIA_ROOT.
    // However, attachment_urls from views.py upload_file seem to be full paths already.
    // Let's log a warning if the URL format is unexpected.
    // console.warn(`getProperUrl: URL "${url}" might need prefixing if not directly usable.`);
    return url; // Return as is for now, assuming it's correct from server.
}

let input_message = $('#input-message');
let send_message_form = $('#send-message-form');
const USER_ID = $('#logged-in-user').val();
let active_thread_id = '';
let active_user_id = null;
let fileInput = $('#file-input');
let messageWrapper = $('#message-wrapper');
var socket;

// Group Chat Variables
let isGroupChat = false;
let currentGroupId = null;
let groupMembers = new Set();

const SUPPORTED_FILE_TYPES = {
    'Images': '.jpg, .jpeg, .png, .gif, .webp, .bmp, .tiff, .svg, .ico, .heic',
    'Videos': '.mp4, .webm, .ogg',
    'Documents': '.pdf, .doc, .docx, .xls, .xlsx'
};

// Get the current user's username from the DOM
const USERNAME = $('#logged-in-user').attr('data-username') || $('h3:contains("Logged in as:")').text().replace('Logged in as:','').trim();

// Initialize the encryption module with the User ID
if (typeof initEncryptionModule === 'function') {
    initEncryptionModule(USER_ID);
} else {
    console.error("initEncryptionModule is not defined. Ensure message-encryption.js is loaded correctly.");
}

function sanitizeInput(input) {
    if (!input) return '';
    return input.replace(/[<>]/g, match => match === '<' ? '&lt;' : '&gt;')
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#x27;')
                .replace(/\//g, '&#x2F;');
}

function sortUserList() {
    let $userList = $('.contacts').first(); // Adjust selector if needed
    let $users = $userList.find('.contact-li:not(.group-chat)');

    $users.sort(function(a, b) {
        // Sort by last communication (desc), then online (desc), then username (asc)
        let commA = parseInt($(a).attr('data-last-comm')) || 0;
        let commB = parseInt($(b).attr('data-last-comm')) || 0;
        if (commA !== commB) return commB - commA;

        let onlineA = parseInt($(a).attr('data-online')) || 0;
        let onlineB = parseInt($(b).attr('data-online')) || 0;
        if (onlineA !== onlineB) return onlineB - onlineA;

        let nameA = $(a).find('.user_info span').text().toLowerCase();
        let nameB = $(b).find('.user_info span').text().toLowerCase();
        return nameA.localeCompare(nameB);
    });

    $userList.prepend($users);
}

// Function to update dark mode icon
function updateDarkModeIcon() {
    if ($('body').hasClass('darkmode')) {
        $('#darkmode-toggle i').removeClass('fa-moon').addClass('fa-sun');
    } else {
        $('#darkmode-toggle i').removeClass('fa-sun').addClass('fa-moon');
    }
}

$(document).ready(function() {
    // Check if dark mode was previously enabled
    if (localStorage.getItem('darkmode') === 'enabled') {
        $('body').addClass('darkmode');
    }
    // Update icon based on current mode
    updateDarkModeIcon();
    
    console.log('DOM ready, checking contacts');
    let firstUser = $('.contact-li').first();
    if (firstUser.length) {
        console.log('First user found, triggering click');
        firstUser.click();
    } else {
        console.log('No contact-li elements found');
    }

    let loc = window.location;
    let wsStart = 'ws://';
    if (loc.protocol === 'https') {
        wsStart = 'wss://';
    }
    let endpoint = wsStart + loc.host + '/home/';
    let uploadUrl = loc.protocol + '//' + loc.host + '/upload/';

    $('.contact-li').on('click', function() {
        $('.contact-li').removeClass('active');
        $(this).addClass('active');

        if ($(this).hasClass('group-chat')) {
            isGroupChat = true;
            currentGroupId = $(this).attr('group-id');
            groupMembers = new Set(JSON.parse($(this).attr('data-members') || '[]'));

            let groupName = $(this).find('.user_info span').text();
            messageWrapper.attr('group-id', currentGroupId);
            $('#message-wrapper .user_info span').text(groupName);
            $('#message-wrapper .user_info p').text(`${groupMembers.size} members`);

            $.ajax({
                url: `/app1/get_group_info/${currentGroupId}/`,
                method: 'GET',
                success: function(response) {
                    if (response.success) {
                        updateGroupActionButtons(response.is_admin);
                    }
                }
            });

            fetch_group_chat_history(currentGroupId);
            $('#chat-header-img').attr('src', '/static/img/group-avatar.svg');
            $('#chat-header-status').removeClass('online offline').hide();
            $('#start-group-video-call').show();
            $('#start-video-call').hide();
        } else {
            isGroupChat = false;
            currentGroupId = null;
            active_user_id = $(this).attr('user-id');

            let username = $(this).find('.user_info span').text();
            messageWrapper.removeAttr('group-id');
            messageWrapper.attr('other-user_id', active_user_id);
            $('#message-wrapper .user_info span').text(username);
            $('#delete-group-btn').hide();
            $('#leave-group-btn').hide();
            $('#show-group-members-btn').hide();

            $(this).find('.user_info p').removeClass('notification');
            let lastMessage = $(this).attr('data-last-message');
            if (lastMessage) {
                $('#message-wrapper .user_info p').text(lastMessage);
            }

            let profilePic = $(this).find('img.user_img').attr('src') || '/static/img/default-avatar.svg';
            let isOnline = $(this).attr('data-online') === '1';
            $('#chat-header-img').attr('src', profilePic);
            $('#chat-header-status').removeClass('online offline').addClass(isOnline ? 'online' : 'offline').show();

            fetch_chat_history(active_user_id);
            $('#start-group-video-call').hide();
            $('#start-video-call').show();
        }
        updateEncryptionToggle();
    });

    send_message_form.on('submit', function(e) {
        e.preventDefault();
        let message = sanitizeInput(input_message.val().trim());
        let files = fileInput[0].files;

        if (!active_user_id && !currentGroupId) {
            showAlert('error', 'Please select a chat to send a message');
            return;
        }

        let formData = new FormData();
        formData.append('sent_by', USER_ID);
        if (isGroupChat) {
            formData.append('group_id', currentGroupId);
            formData.append('is_group_message', true);
        } else {
            formData.append('send_to', active_user_id);
            formData.append('is_group_message', false);
        }
        if (message) formData.append('message', message);
        for (let i = 0; i < files.length; i++) {
            if (!validateFile(files[i])) {
                return;
            }
            formData.append('files', files[i]);
        }

        if (files.length > 0) {
            $.ajax({
                url: uploadUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log('[File Upload] Success:', response);
                    if (response && response.attachment_urls && response.attachment_names && response.attachment_paths) {
                        sendMessage(message, response.attachment_urls, response.attachment_names, response.attachment_paths);
                    } else {
                        console.error('[File Upload] Success callback, but response is malformed or missing attachment data (urls, names, or paths).', response);
                        showAlert('error', 'File upload succeeded but data was incomplete. Please try again.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('File upload failed:', error);
                }
            });
        } else if (message) { // Only message, no files
            sendMessage(message, [], {}, {}); // Pass empty attachment_paths
        }
    });

    function showSupportedFileTypes() {
        let alertHtml = `
            <div class="alert alert-info alert-dismissible fade show" role="alert" style="position: fixed; top: 10px; left: 50%; transform: translateX(-50%); z-index: 1050; min-width: 300px;">
                <strong>Supported File Types:</strong><br>
                <small>
                    Images: ${SUPPORTED_FILE_TYPES.Images}<br>
                    Videos: ${SUPPORTED_FILE_TYPES.Videos}<br>
                    Documents: ${SUPPORTED_FILE_TYPES.Documents}<br>
                    Max size: 50MB
                </small>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>`;
        
        // Remove any existing alerts
        $('.alert').alert('close');
        
        // Add new alert
        $('body').append(alertHtml);
    }

    function validateFile(file) {
        const maxSize = 50 * 1024 * 1024; // 50MB
        
        if (file.size > maxSize) {
            showSupportedFileTypes();
            return false;
        }

        const fileName = file.name.toLowerCase();
        const fileExt = '.' + fileName.split('.').pop();

        // Check if file extension is in any of the supported types
        const isSupported = Object.values(SUPPORTED_FILE_TYPES).some(types => 
            types.split(',').map(t => t.trim().toLowerCase()).includes(fileExt)
        );

        if (!isSupported) {
            showSupportedFileTypes();
            return false;
        }

        return true;
    }

    function sendMessage(message, attachment_urls = [], attachment_names = {}, attachment_paths = {}) {
        if (!active_user_id && !currentGroupId) {
            showAlert('error', 'Please select a chat to send a message');
            return;
        }

        let originalMessage = message;
        let message_to_send = originalMessage;
        let client_did_encrypt = false;
        
        if (!isGroupChat && originalMessage && isEncryptionEnabledForUser(active_user_id)) {
            message_to_send = encryptMessage(originalMessage, active_user_id);
            client_did_encrypt = true;
            console.log("Client encrypted message for E2EE. Flagging client_did_encrypt=true");
        }

        let messageData = {
            'message': message_to_send,
            'sent_by': USER_ID,
            'attachment_urls': attachment_urls,
            'attachment_names': attachment_names,
            'attachment_paths': attachment_paths,
            'client_did_encrypt': client_did_encrypt
        };

        if (isGroupChat) {
            messageData.is_group_message = true;
            messageData.group_id = currentGroupId;
        } else {
            messageData.is_group_message = false;
            messageData.send_to = active_user_id;
        }

        if (isGroupChat) {
            // For group chat, server echo is typically used to display.
            // Current: "Do not display immediately; wait for WebSocket echo to avoid double message"
        } else {
            // For 1-to-1, sender sees the original unencrypted message and attachments immediately.
            // The attachment_paths are not directly used for optimistic display here, urls are sufficient.
            newMessage(originalMessage, USER_ID, active_thread_id, attachment_urls, attachment_names, null, new Date().toISOString());
        }
        
        console.log('[SendMessage] Preparing messageData to send via WebSocket:', messageData);
        socket.send(JSON.stringify(messageData));

        input_message.val('');
        fileInput.val('');
    }

    function handleChatMessage(data) {
        console.warn("handleChatMessage function was called, but logic should be in main onmessage handler now.");
    }

    function updateMessagePreview(userId, message, hasAttachment) {
        let userThread = $(`.contact-li[user-id="${userId}"]`);
        if (userThread.length) {
            let previewText = sanitizeInput(message) || (hasAttachment ? 'New attachment' : 'New message');
            if (previewText.length > 30) {
                previewText = previewText.substring(0, 30) + '...';
            }
            
            userThread.attr('data-last-message', previewText);
            
            if (active_user_id !== userId) {
                userThread.find('.user_info p')
                    .html(`<strong>New message: ${previewText}</strong>`)
                    .addClass('notification');
            } else {
                userThread.find('.user_info p').text(previewText);
            }
        }
    }

    function newMessage(messageContent, sent_by_id, thread_id_or_group_id, attachment_urls, attachment_names, sender_name, timestamp_str) {
        if (!messageContent && (!attachment_urls || !attachment_urls.length)) return;

        let sanitizedMessage = sanitizeInput(messageContent);
        
        let displayTime;
        if (timestamp_str) {
            try {
                const dateObj = new Date(timestamp_str.replace(' ', 'T') + 'Z');
                if (isNaN(dateObj)) {
                    displayTime = timestamp_str;
                } else {
                    displayTime = dateObj.toLocaleString();
                }
            } catch(e) {
                displayTime = timestamp_str;
            }
        } else {
            displayTime = new Date().toLocaleString();
        }

        let senderDisplay = '';
        if (isGroupChat && sender_name) {
            senderDisplay = `<div class="sender-name" style="font-weight: bold; color: #17a2b8;">${sanitizeInput(sender_name)}</div>`;
        }
        
        let encryptionStatus = '';
        if (!isGroupChat && active_user_id && isEncryptionEnabledForUser(active_user_id)) {
            encryptionStatus = `<div class="encryption-status" style="font-size: 0.7em; opacity: 0.6;"><i class="fas fa-lock"></i> E2E Encrypted</div>`;
        }

        let message_element = '';
        const messageContainerClass = sent_by_id === USER_ID ? "replied" : "received";
        const messageClass = sent_by_id === USER_ID ? "msg_cotainer_send" : "msg_cotainer";

        message_element = `
            <div class="d-flex justify-content-${sent_by_id === USER_ID ? 'end' : 'start'} mb-4 ${messageContainerClass}">
                <div class="${messageClass}">
                    ${senderDisplay}
                    ${sanitizedMessage ? `<div class="message-text mb-2">${sanitizedMessage}</div>` : ''}
                    ${attachment_urls && attachment_urls.map(url => {
                        const fullUrl = getProperUrl(url);
                        const fileExt = (url.split('.').pop() || '').toLowerCase();
                        const originalName = sanitizeInput(attachment_names[url] || url.split('/').pop());
                        if (["jpg","jpeg","png","gif","webp","bmp","tiff","svg","ico","heic","heif"].includes(fileExt)) {
                            return `<div class="message-attachment mb-2"><img src="${fullUrl}" alt="${originalName}" style="max-width: 300px; max-height: 400px; border-radius: 8px; cursor: pointer; object-fit: contain;" onclick="window.open('${fullUrl}', '_blank')"></div>`;
                        } else if (["pdf","doc","docx","xls","xlsx"].includes(fileExt)) {
                            const fileIcon = fileExt === 'pdf' ? '📄' : ["doc","docx"].includes(fileExt) ? '📝' : '📊';
                            return `<div class="message-attachment file-attachment mb-2" style="background: rgba(255,255,255,0.1); padding: 12px; border-radius: 8px; display: flex; align-items: center; gap: 8px;"><span style="font-size: 24px;">${fileIcon}</span><a href="${fullUrl}" target="_blank" class="file-download" style="color: inherit; text-decoration: none; word-break: break-word;">${originalName}</a></div>`;
                        } else if (["mp4","webm","ogg"].includes(fileExt)) {
                            return `<div class="message-attachment mb-2"><video controls style="max-width: 300px; border-radius: 8px;" preload="metadata"><source src="${fullUrl}" type="video/${fileExt}">Your browser does not support the video tag.</video></div>`;
                        } else {
                            return `<div class="message-attachment file-attachment mb-2" style="background: rgba(255,255,255,0.1); padding: 12px; border-radius: 8px; display: flex; align-items: center; gap: 8px;"><span style="font-size: 24px;">📎</span><a href="${fullUrl}" target="_blank" class="file-download" style="color: inherit; text-decoration: none; word-break: break-word;">${originalName}</a></div>`;
                        }
                    }).join('')}
                    ${encryptionStatus}
                    <span class="msg_time" style="font-size: 0.75em; opacity: 0.7;">${displayTime}</span>
                </div>
            </div>`;
        
        let msgBody = messageWrapper.find('.msg_card_body');
        msgBody.append(message_element);
        msgBody.scrollTop(msgBody[0].scrollHeight);
    }

    function updateMessageCount() {
        let msgBody = messageWrapper.find('.msg_card_body');
        let count = msgBody.find('.received, .replied').length;
        messageWrapper.find('.user_info p').text(count + ' messages');
    }

    function appendMessage(messageData) {
        let { message, sent_by_id, thread_id, attachment_urls, attachment_names, send_to } = messageData;
        thread_id = thread_id || '';
        
        if (active_user_id === (sent_by_id === USER_ID ? send_to : sent_by_id)) {
            newMessage(message, sent_by_id, thread_id, attachment_urls, attachment_names);
        } else {
            let senderId = sent_by_id === USER_ID ? send_to : sent_by_id;
            let userThread = $(`.contact-li[user-id="${senderId}"]`);
            
            if (userThread.length) {
                let previewText = message || 'New attachment';
                if (previewText.length > 30) {
                    previewText = previewText.substring(0, 30) + '...';
                }
                
                userThread.attr('data-last-message', previewText);
                
                userThread.find('.user_info p')
                    .html(`<strong>New message: ${previewText}</strong>`)
                    .addClass('notification');
            }
        }
    }

    function fetch_chat_history(other_user_id) {
        messageWrapper.find('.msg_card_body').empty();
        
        $.ajax({
            url: '/app1/fetch_chat_history/',
            method: 'GET',
            data: {
                other_user_id: other_user_id,
                current_user_id: USER_ID
            },
            success: function(response) {
                console.log('Chat history fetched:', response);
                if (response.thread_id) {
                    active_thread_id = String(response.thread_id);
                    messageWrapper.attr('chat-id', 'chat_' + active_thread_id);
                }
                if (response.messages && response.messages.length > 0) {
                    response.messages.forEach(function(msg) {
                        let message_from_db = msg.message;
                        let sent_by_id = msg.sent_by;
                        let attachment_urls = msg.attachment_urls || [];
                        let attachment_names = msg.attachment_names || {}; 
                        let is_encrypted_from_db = msg.is_encrypted || false;
                        let timestamp_from_db = msg.timestamp;

                        let final_message_for_display = message_from_db;
                        if (is_encrypted_from_db && sent_by_id !== USER_ID) {
                            console.log(`History: Decrypting message from ${sent_by_id}`);
                            final_message_for_display = decryptMessage(message_from_db, sent_by_id);
                        }
                        newMessage(final_message_for_display, sent_by_id, active_thread_id, attachment_urls, attachment_names, null, timestamp_from_db);
                    });
                    
                    let lastMsg = response.messages[response.messages.length - 1];
                    let previewText = lastMsg.message; 
                    if (lastMsg.is_encrypted && lastMsg.sent_by !== USER_ID) {
                        try {
                            previewText = decryptMessage(lastMsg.message, lastMsg.sent_by) || "[Encrypted Attachment]";
                        } catch (e) { previewText = "[Encrypted Message]"; }
                    } else if (!lastMsg.message && (lastMsg.attachment_urls || []).length > 0) {
                        previewText = "Attachment";
                    }

                    if (previewText && previewText.length > 30) {
                        previewText = previewText.substring(0, 30) + '...';
                    }
                    
                    let userThread = $(`.contact-li[user-id="${other_user_id}"]`);
                    userThread.attr('data-last-message', sanitizeInput(previewText));
                    userThread.find('.user_info p')
                        .text(sanitizeInput(previewText))
                        .removeClass('notification');
                    
                    let msgBody = messageWrapper.find('.msg_card_body');
                    msgBody.scrollTop(msgBody[0].scrollHeight);
                }
                
                updateMessageCount();
            },
            error: function(xhr, status, error) {
                console.error('Failed to fetch chat history:', error);
                messageWrapper.find('.msg_card_body').html(
                    '<div class="text-center text-danger">Failed to load chat history. Please try again.</div>'
                );
            }
        });
    }

    function fetch_group_chat_history(groupId) {
        messageWrapper.find('.msg_card_body').empty();
        
        $.ajax({
            url: '/app1/fetch_group_chat_history/',
            method: 'GET',
            data: {
                group_id: groupId
            },
            success: function(response) {
                if (response.messages && response.messages.length > 0) {
                    response.messages.forEach(function(msg) {
                        newMessage(
                            msg.message,
                            msg.sent_by,
                            msg.thread_id,
                            msg.attachment_urls || [],
                            msg.attachment_names || {},
                            msg.sender_name,
                            msg.timestamp
                        );
                    });
                    
                    let msgBody = messageWrapper.find('.msg_card_body');
                    msgBody.scrollTop(msgBody[0].scrollHeight);
                }
                updateMessageCount();
            },
            error: function(xhr, status, error) {
                console.error('Failed to fetch group chat history:', error);
                messageWrapper.find('.msg_card_body').html(
                    '<div class="text-center text-danger">Failed to load group chat history. Please try again.</div>'
                );
            }
        });
    }

    let wsReconnectAttempts = 0;
    const MAX_RECONNECT_ATTEMPTS = 5;
    const INITIAL_RECONNECT_DELAY = 1000;

    function initWebSocket() {
        let loc = window.location;
        let wsStart = 'ws://';
        if (loc.protocol === 'https') {
            wsStart = 'wss://';
        }
        let endpoint = wsStart + loc.host + '/home/';
        
        socket = new WebSocket(endpoint);
        
        socket.onopen = function(e) {
            console.log('WebSocket connected');
            wsReconnectAttempts = 0;
            
            if (!window.videoCall) {
                window.videoCall = new VideoCall(socket);
            } else {
                window.videoCall.socket = socket;
            }
        };
        
        socket.onclose = function(e) {
            if (wsReconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                const delay = Math.min(1000 * Math.pow(2, wsReconnectAttempts), 30000);
                console.log(`WebSocket disconnected. Reconnecting in ${delay/1000} seconds... (Attempt ${wsReconnectAttempts + 1}/${MAX_RECONNECT_ATTEMPTS})`);
                setTimeout(initWebSocket, delay);
                wsReconnectAttempts++;
            } else {
                console.log('WebSocket reconnection failed after maximum attempts. Please refresh the page.');
                showAlert('error', 'Connection lost. Please refresh the page to reconnect.');
            }
        };
        
        socket.onerror = function(e) {
            console.error('WebSocket error:', e);
        };
        
        socket.onmessage = function(e) {
            try {
                const rawData = e.data;
                console.log("[WebSocket] Raw message received:", rawData.substring(0, 100) + "..."); // Log raw data

                const data = JSON.parse(rawData);
                console.log("[WebSocket] Parsed message data:", data);

                if (data.type === 'video-call' && window.videoCall) {
                    window.videoCall.handleWebSocketMessage(data);
                    return;
                }
                
                if (data.type === 'group_call_invite') {
                    showGroupCallNotification(data.caller, data.room_name, data.group_id);
                    return;
                }

                if (data.type === 'group_message') {
                    const { message, sent_by, group_id, attachment_urls, attachment_names, sender_name, timestamp } = data;
                    if (isGroupChat && currentGroupId === group_id) {
                        newMessage(message, sent_by, group_id, attachment_urls || [], attachment_names || {}, sender_name, timestamp);
                    } else {
                        let groupThread = $(`.contact-li[data-group-id="${group_id}"]`);
                        let previewText = sanitizeInput(message);
                        if (previewText.length > 30) previewText = previewText.substring(0, 30) + "...";
                        else if (!previewText && (attachment_urls || []).length > 0) previewText = "New attachment";
                        else if (!previewText) previewText = "New message";

                        groupThread.find('.user_info p')
                            .html(`<strong>New message: ${previewText}</strong>`)
                            .addClass('notification');
                    }
                    return;
                }

                if (data.type === 'chat_message') {
                    let { message, sent_by, send_to, thread_id, attachment_urls, attachment_names, timestamp, is_encrypted } = data;
                    
                    attachment_urls = attachment_urls || [];
                    attachment_names = attachment_names || {};

                    if (sent_by === USER_ID) {
                        console.log(`[WebSocket] Sender's Echo (1-to-1): Message from ${sent_by} to ${send_to}. Active user: ${active_user_id}. Thread: ${thread_id}. This message will be IGNORED for display.`);
                        if (send_to !== active_user_id) {
                            console.warn(`[WebSocket] Sender's Echo MISMATCH: Sent to ${send_to} but active user is ${active_user_id}. This is unusual for a direct echo.`);
                        }
                        return;
                    }

                    let final_message_content = message;
                    if (is_encrypted && sent_by !== USER_ID) {
                        console.log(`History: Decrypting message from ${sent_by}`);
                        final_message_content = decryptMessage(message, sent_by);
                    }

                    if (!active_thread_id && thread_id) {
                        active_thread_id = thread_id;
                    }

                    if (send_to === USER_ID) {
                        if (sent_by === active_user_id) {
                            console.log(`[WebSocket] Receiver: Displaying message from ${sent_by} in active chat.`);
                            newMessage(final_message_content, sent_by, thread_id, attachment_urls, attachment_names, null, timestamp);
                        } else {
                            console.log(`[WebSocket] Receiver: Updating message preview for inactive chat with ${sent_by}.`);
                            updateMessagePreview(sent_by, final_message_content, attachment_urls.length > 0);
                        }
                    }
                    return;
                }
                
                console.log("[WebSocket] Unhandled WebSocket message type or structure:", data);

            } catch (err) {
                console.error('[WebSocket] Failed to parse or process WebSocket message:', err, "Raw data:", e.data);
            }
        };
    }

    initWebSocket();

    $('#create-group-btn').on('click', function() {
        loadAvailableMembers();
        $('#createGroupModal').modal('show');
    });

    function loadAvailableMembers() {
        $('.member-selection').empty();
        $('.contact-li:not(.group-chat)').each(function() {
            let userId = $(this).attr('user-id');
            let username = $(this).find('.user_info span').text();
            
            if (userId && userId !== USER_ID) {
                $('.member-selection').append(`
                    <div class="custom-control custom-checkbox mb-2">
                        <input type="checkbox" class="custom-control-input" id="member-${userId}" value="${userId}">
                        <label class="custom-control-label" for="member-${userId}">
                            <div class="d-flex align-items-center">
                                <img src="/static/img/default-avatar.png" class="rounded-circle" width="30" height="30">
                                <span class="ml-2">${sanitizeInput(username)}</span>
                            </div>
                        </label>
                    </div>
                `);
            }
        });
    }

    $(document).ready(function() {
        $('.modal').modal({
            show: false
        });

        $('.modal .close').on('click', function() {
            $(this).closest('.modal').modal('hide');
        });

        $('#createGroupModal').on('hidden.bs.modal', function() {
            $('#groupName').val('');
            $('.member-selection input').prop('checked', false);
        });
    });

    $('#createGroupSubmit').on('click', function() {
        const groupName = $('#groupName').val().trim();
        const groupDescription = $('#group-description').val().trim();
        const selectedMembers = [];
    
        $('.member-selection input:checked').each(function() {
            selectedMembers.push($(this).val());
        });
    
        if (!groupName) {
            showAlert('error', 'Please enter a valid group name');
            return;
        }
    
        if (selectedMembers.length === 0) {
            showAlert('error', 'Please select at least one member');
            return;
        }
    
        if (!selectedMembers.includes(USER_ID)) {
            selectedMembers.push(USER_ID);
        }
    
        const csrftoken = getCookie('csrftoken');
    
        $.ajax({
            url: '/app1/create_group/',
            method: 'POST',
            data: {
                name: groupName,
                description: groupDescription,
                members: JSON.stringify(selectedMembers)
            },
            headers: {
                'X-CSRFToken': csrftoken
            },
            success: function(response) {
                if (response.success) {
                    addGroupToContacts(response.group_id, groupName, selectedMembers);
                    $('#createGroupModal').modal('hide');
                    showAlert('success', 'Group created successfully!');
                    $('#groupName').val('');
                    $('.member-selection input').prop('checked', false);
                } else {
                    showAlert('error', response.error || 'Failed to create group. Please try again.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Group creation error:', error);
                showAlert('error', 'An error occurred while creating the group. Please try again.');
            },
            complete: function() {
                $submitBtn.prop('disabled', false);
            }
        });
    });

    function showAlert(type, message, isDismissible = true, isFileTypeError = false) {
        let alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        let alertHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert" 
                 style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 9999; min-width: 300px; 
                        background-color: #fff; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px;">
                <div style="display: flex; align-items: start; justify-content: space-between; gap: 10px;">
                    <div>
                        ${type === 'error' ? '❌' : '✅'} 
                        <span style="margin-left: 8px;">${message}</span>
                    </div>
                    <button type="button" class="close" style="font-size: 1.5rem; font-weight: 700; line-height: 1; 
                            color: #000; text-shadow: 0 1px 0 #fff; opacity: .5; background: none; border: none; 
                            padding: 0; cursor: pointer;" onclick="this.parentElement.parentElement.remove();">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                ${isFileTypeError ? `
                <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #dee2e6;">
                    <strong>Supported File Types:</strong><br>
                    <small>
                        Images: ${SUPPORTED_FILE_TYPES.Images}<br>
                        Videos: ${SUPPORTED_FILE_TYPES.Videos}<br>
                        Documents: ${SUPPORTED_FILE_TYPES.Documents}<br>
                        Max size: 50MB
                    </small>
                </div>` : ''}
            </div>`;

        $('.alert').remove();
        
        $('body').append(alertHtml);

        if (!isFileTypeError) {
            setTimeout(() => {
                $('.alert').fadeOut(300, function() { $(this).remove(); });
            }, 5000);
        }
    }

    function addGroupToContacts(groupId, groupName, members) {
        let groupElement = `
            <li class="contact-li group-chat" data-group-id="${groupId}">
                <div class="d-flex bd-highlight">
                    <div class="img_cont">
                        <img src="/static/img/group-avatar.png" class="rounded-circle user_img">
                        <span class="group_icon"><i class="fas fa-users"></i></span>
                    </div>
                    <div class="user_info">
                        <span>${sanitizeInput(groupName)}</span>
                        <p>${members.length} members</p>
                    </div>
                </div>
            </li>`;

        $('.contacts').append(groupElement);

        $(`.contact-li[data-group-id="${groupId}"]`).on('click', function() {
            $('.contact-li').removeClass('active');
            $(this).addClass('active');
            currentGroupId = groupId;
            active_user_id = null;
            isGroupChat = true;
            loadGroupChat(groupId);
        });
    }

    function loadGroupChat(groupId) {
        $.ajax({
            url: '/get_group_chat/',
            method: 'GET',
            data: { group_id: groupId },
            success: function(response) {
                if (response.success) {
                    messageWrapper.find('.msg_card_body').empty();
                    response.messages.forEach(function(msg) {
                        newMessage(
                            msg.message,
                            msg.sent_by,
                            groupId,
                            msg.attachments || [],
                            msg.attachment_names || {},
                            msg.sender_name
                        );
                    });
                } else {
                    showAlert('error', 'Failed to load group chat. Please try again.');
                }
            },
            error: function() {
                showAlert('error', 'An error occurred while loading group chat.');
            }
        });
    }

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    function updateGroupActionButtons(isAdmin) {
        if (isAdmin) {
            $('#delete-group-btn').show();
            $('#leave-group-btn').show();
            $('#show-group-members-btn').show();
        } else {
            $('#delete-group-btn').hide();
            $('#leave-group-btn').show();
            $('#show-group-members-btn').show();
        }
    }

    $('#delete-group-btn').off('click').on('click', function() {
        if (confirm('Are you sure you want to delete this group?')) {
            $.ajax({
                url: `/app1/delete_group/${currentGroupId}/`,
                method: 'POST',
                headers: {'X-CSRFToken': getCookie('csrftoken')},
                success: function(response) {
                    if (response.success) {
                        showAlert('success', 'Group deleted!');
                        $(`.contact-li[data-group-id="${currentGroupId}"]`).remove();
                        $('#message-wrapper .msg_card_body').empty();
                        $('#message-wrapper .user_info span').text('Select a user to start chatting');
                        $('#message-wrapper .user_info p').text('0 messages');
                        $('#delete-group-btn').hide();
                        $('#leave-group-btn').hide();
                    } else {
                        showAlert('error', response.error || 'Failed to delete group.');
                    }
                }
            });
        }
    });

    $('#leave-group-btn').off('click').on('click', function() {
        if (confirm('Are you sure you want to leave this group?')) {
            $.ajax({
                url: `/app1/leave_group/${currentGroupId}/`,
                method: 'POST',
                headers: {'X-CSRFToken': getCookie('csrftoken')},
                success: function(response) {
                    if (response.success) {
                        showAlert('success', 'You left the group.');
                        $(`.contact-li[data-group-id="${currentGroupId}"]`).remove();
                        $('#message-wrapper .msg_card_body').empty();
                        $('#message-wrapper .user_info span').text('Select a user to start chatting');
                        $('#message-wrapper .user_info p').text('0 messages');
                        $('#delete-group-btn').hide();
                        $('#leave-group-btn').hide();
                    } else {
                        showAlert('error', response.error || 'Failed to leave group.');
                    }
                }
            });
        }
    });

    $('#show-group-members-btn').off('click').on('click', function() {
        if (!currentGroupId) return;
        $.ajax({
            url: `/app1/get_group_info/${currentGroupId}/`,
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    const members = response.members;
                    const isAdmin = response.is_admin;
                    const currentUserId = USER_ID;
                    let html = '';
                    members.forEach(member => {
                        html += `<li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>${member.username} ${member.is_admin ? '<span class=\'badge badge-primary ml-2\'>Admin</span>' : ''}</span>`;
                        if (isAdmin && member.id != currentUserId) {
                            html += `<button class="btn btn-sm btn-danger remove-member-btn" data-user-id="${member.id}">Remove</button>`;
                        }
                        html += `</li>`;
                    });
                    $('#group-members-list').html(html);
                    $('#groupMembersModal').modal('show');
                }
            }
        });
    });

    $(document).on('click', '.remove-member-btn', function() {
        const userId = $(this).data('user-id');
        if (!currentGroupId || !userId) return;
        if (!confirm('Are you sure you want to remove this member from the group?')) return;
        $.ajax({
            url: `/app1/manage_group_members/${currentGroupId}/`,
            method: 'POST',
            headers: {'X-CSRFToken': getCookie('csrftoken')},
            data: JSON.stringify({action: 'remove', user_id: userId}),
            contentType: 'application/json',
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Member removed from group.');
                    $('#show-group-members-btn').click();
                } else {
                    showAlert('error', response.error || 'Failed to remove member.');
                }
            }
        });
    });

    $('.search').on('input', function() {
        let searchVal = $(this).val().toLowerCase();
        $('.contacts .contact-li:not(.group-chat)').each(function() {
            let username = $(this).find('.user_info span').text().toLowerCase();
            if (username.includes(searchVal)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    sortUserList();

    $('#darkmode-toggle').on('click', function() {
        $('body').toggleClass('darkmode');
        localStorage.setItem('darkmode', $('body').hasClass('darkmode') ? 'enabled' : 'disabled');
        updateDarkModeIcon();
    });

    $('#settings-btn').on('click', function() {
        $('#profileModal').modal('show');
    });

    $('#profilePicInput').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#profilePicPreview').attr('src', e.target.result);
            }
            reader.readAsDataURL(file);
        }
    });

    $('#profileForm').on('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        $.ajax({
            url: '/app1/update_profile/',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {'X-CSRFToken': getCookie('csrftoken')},
            success: function(response) {
                if (response.success) {
                    $('.sidebar-profile img').attr('src', response.profile_pic_url);
                    showAlert('success', 'Profile updated!');
                    $('#profileModal').modal('hide');
                } else {
                    showAlert('error', response.error || 'Failed to update profile.');
                }
            },
            error: function() {
                showAlert('error', 'An error occurred while updating profile.');
            }
        });
    });

    $('#start-group-video-call').off('click').on('click', function() {
        if (!currentGroupId) return;
        
        if (typeof videoCall !== 'undefined' && videoCall.checkPermissions) {
            videoCall.checkPermissions().then(permissionsGranted => {
                if (permissionsGranted) {
                    initiateGroupCall();
                } else {
                    $('#permissionModal').modal('show');
                    videoCall.pendingGroupCall = currentGroupId;
                }
            });
        } else {
            initiateGroupCall();
        }
        
        function initiateGroupCall() {
            $.ajax({
                url: `/app1/video-call/room/create/${currentGroupId}/`,
                method: 'GET',
                success: function(response) {
                    if (response.room_name) {
                        window.location.href = `/app1/video-call/${response.room_name}/?group_id=${currentGroupId}`;
                    } else {
                        showAlert('error', 'Failed to create group video call room.');
                    }
                },
                error: function() {
                    showAlert('error', 'Failed to create group video call room.');
                }
            });
        }
    });

    function showGroupCallNotification(caller, roomName, groupId) {
        $('#callNotification').show();
        $('#callerName').text(`${caller} is starting a group call`);
        $('#acceptCall').off('click').on('click', function() {
            $('#callNotification').hide();
            window.location.href = `/app1/video-call/${roomName}/?group_id=${groupId}`;
        });
        $('#rejectCall').off('click').on('click', function() {
            $('#callNotification').hide();
            if (typeof socket !== 'undefined') {
                socket.send(JSON.stringify({
                    type: 'video-call',
                    action: 'reject-group-call',
                    room_name: roomName,
                    group_id: groupId
                }));
            }
        });
    }

    $('#retryPermissions').on('click', async function() {
        if (typeof videoCall !== 'undefined' && videoCall.checkPermissions) {
            const success = await videoCall.checkPermissions();
            if (success) {
                $('#permissionModal').modal('hide');
                if (videoCall.pendingGroupCall) {
                    const groupId = videoCall.pendingGroupCall;
                    videoCall.pendingGroupCall = null;
                    $('#start-group-video-call').click();
                }
            }
        }
    });

    const encryptionToggle = $('#encryption-toggle');
    
    function updateEncryptionToggle() {
        if (isGroupChat || !active_user_id) {
            encryptionToggle.hide();
        } else {
            encryptionToggle.show();
            updateEncryptionToggleUI();
        }
    }
    
    function updateEncryptionToggleUI() {
        const isEnabled = isEncryptionEnabledForUser(active_user_id);
        if (isEnabled) {
            encryptionToggle.addClass('btn-success').removeClass('btn-outline-secondary');
            encryptionToggle.find('i').removeClass('fa-unlock').addClass('fa-lock');
            encryptionToggle.attr('title', 'Encryption Enabled - Click to Disable');
        } else {
            encryptionToggle.removeClass('btn-success').addClass('btn-outline-secondary');
            encryptionToggle.find('i').removeClass('fa-lock').addClass('fa-unlock');
            encryptionToggle.attr('title', 'Encryption Disabled - Click to Enable');
        }
    }
    
    encryptionToggle.on('click', function() {
        const currentState = isEncryptionEnabledForUser(active_user_id);
        setEncryptionEnabled(active_user_id, !currentState);
        updateEncryptionToggleUI();
        
        const statusMsg = !currentState ? 
            'End-to-end encryption enabled for this chat' : 
            'Encryption disabled for this chat';
        
        showAlert(!currentState ? 'success' : 'warning', statusMsg);
    });
    
    $('.contact-li').on('click', function() {
        setTimeout(updateEncryptionToggle, 100);
    });
});