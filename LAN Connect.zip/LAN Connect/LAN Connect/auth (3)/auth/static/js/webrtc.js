// WebRTC connection handling
const peerConnections = {};
const dataChannels = {};

async function initializeGroupCall() {
    if (!isIncomingCall) {
        // Caller initializes connections with all participants
        await createPeerConnections();
    }
    // Incoming calls wait for offers
}

async function createPeerConnections() {
    try {
        const participants = JSON.parse(document.getElementById('participants').textContent);
        
        for (const participant of participants) {
            if (participant.id === currentUserId) continue;
            
            await createPeerConnection(participant.id);
        }
    } catch (error) {
        console.error('Error creating peer connections:', error);
        handleConnectionError(error);
    }
}

async function createPeerConnection(participantId) {
    try {
        const peerConnection = new RTCPeerConnection(iceServers);
        peerConnections[participantId] = peerConnection;

        // Add local tracks to the connection
        if (localStream) {
            localStream.getTracks().forEach(track => {
                peerConnection.addTrack(track, localStream);
            });
        }

        // Create data channel
        const dataChannel = peerConnection.createDataChannel('messageChannel');
        setupDataChannel(dataChannel, participantId);
        dataChannels[participantId] = dataChannel;

        // Handle ICE candidates
        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                signalingSocket.send(JSON.stringify({
                    type: 'ice_candidate',
                    candidate: event.candidate,
                    target_id: participantId
                }));
            }
        };

        // Handle connection state changes
        peerConnection.onconnectionstatechange = () => {
            updateConnectionStatus(participantId, peerConnection.connectionState);
        };

        // Handle incoming tracks
        peerConnection.ontrack = (event) => {
            handleRemoteTrack(event, participantId);
        };

        // Create and send offer if initiator
        if (!isIncomingCall) {
            const offer = await peerConnection.createOffer();
            await peerConnection.setLocalDescription(offer);
            
            signalingSocket.send(JSON.stringify({
                type: 'offer',
                offer: offer,
                target_id: participantId
            }));
        }

        return peerConnection;
    } catch (error) {
        console.error('Error creating peer connection:', error);
        handleConnectionError(error);
    }
}

async function handleOffer(data) {
    try {
        const peerConnection = await createPeerConnection(data.sender_id);
        await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
        
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);
        
        signalingSocket.send(JSON.stringify({
            type: 'answer',
            answer: answer,
            target_id: data.sender_id
        }));
    } catch (error) {
        console.error('Error handling offer:', error);
        handleConnectionError(error);
    }
}

async function handleAnswer(data) {
    try {
        const peerConnection = peerConnections[data.sender_id];
        if (peerConnection) {
            await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
        }
    } catch (error) {
        console.error('Error handling answer:', error);
        handleConnectionError(error);
    }
}

async function handleIceCandidate(data) {
    try {
        const peerConnection = peerConnections[data.sender_id];
        if (peerConnection) {
            await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    } catch (error) {
        console.error('Error handling ICE candidate:', error);
        handleConnectionError(error);
    }
}

function handleRemoteTrack(event, participantId) {
    if (event.streams && event.streams[0]) {
        const remoteVideo = document.querySelector(`[data-user-id="${participantId}"] video`);
        if (!remoteVideo) {
            // Create new video element for participant
            const videoWrapper = document.createElement('div');
            videoWrapper.className = 'video-wrapper';
            videoWrapper.setAttribute('data-user-id', participantId);
            
            const video = document.createElement('video');
            video.autoplay = true;
            video.playsInline = true;
            video.srcObject = event.streams[0];
            
            const participantName = document.createElement('div');
            participantName.className = 'participant-name';
            participantName.textContent = getParticipantName(participantId);
            
            const connectionStatus = document.createElement('div');
            connectionStatus.className = 'connection-status';
            
            const participantStatus = document.createElement('div');
            participantStatus.className = 'participant-status';
            participantStatus.textContent = 'Connected';
            
            videoWrapper.appendChild(video);
            videoWrapper.appendChild(participantName);
            videoWrapper.appendChild(connectionStatus);
            videoWrapper.appendChild(participantStatus);
            
            document.getElementById('videoGrid').appendChild(videoWrapper);
        } else {
            remoteVideo.srcObject = event.streams[0];
        }
    }
}

function updateConnectionStatus(participantId, state) {
    const statusElement = document.querySelector(`[data-user-id="${participantId}"] .connection-status`);
    if (statusElement) {
        statusElement.textContent = state.charAt(0).toUpperCase() + state.slice(1);
        statusElement.className = `connection-status ${state}`;
    }
}

function setupDataChannel(dataChannel, participantId) {
    dataChannel.onmessage = (event) => {
        handleDataChannelMessage(JSON.parse(event.data), participantId);
    };
    
    dataChannel.onopen = () => {
        console.log(`Data channel opened with participant ${participantId}`);
    };
    
    dataChannel.onclose = () => {
        console.log(`Data channel closed with participant ${participantId}`);
    };
}

function handleDataChannelMessage(message, senderId) {
    // Handle chat messages or other data channel communications
    console.log('Received message from', senderId, ':', message);
}

function getParticipantName(participantId) {
    const participants = JSON.parse(document.getElementById('participants').textContent);
    const participant = participants.find(p => p.id === participantId);
    return participant ? participant.name : 'Unknown';
}

function handleConnectionError(error) {
    console.error('WebRTC Error:', error);
    // Update UI to show error state
    const errorMessage = document.createElement('div');
    errorMessage.className = 'error-message';
    errorMessage.textContent = 'Connection error. Please try rejoining the call.';
    document.querySelector('.video-container').appendChild(errorMessage);
}

// Clean up connections when leaving
window.addEventListener('beforeunload', () => {
    Object.values(peerConnections).forEach(pc => pc.close());
    Object.values(dataChannels).forEach(dc => dc.close());
}); 