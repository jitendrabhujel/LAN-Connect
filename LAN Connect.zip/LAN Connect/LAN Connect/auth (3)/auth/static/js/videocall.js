class VideoCall {
    constructor(socket) {
        this.socket = socket;
        this.localStream = null;
        this.remoteStream = null;
        this.peerConnection = null;
        this.isInitiator = false;
        this.remoteUserId = null;
        this.localVideo = document.getElementById('localVideo');
        this.remoteVideo = document.getElementById('remoteVideo');
        this.isAudioMuted = false;
        this.isVideoOff = false;
        this.callEnded = false;
        this.pendingCall = null;
        this.pendingGroupCall = null;
        this.pendingCandidates = []; // Store candidates that arrive before peer connection is ready
        this.recordedChunks = [];
        this.mediaRecorder = null;
        this.isGroupCall = false;
        this.peerConnections = {}; // For group calls, store multiple peer connections

        // Enhanced WebRTC configuration with multiple STUN servers and TURN support
        this.configuration = {
            iceServers: [
                { 
                    urls: [
                        'stun:stun.l.google.com:19302',
                        'stun:stun1.l.google.com:19302',
                        'stun:stun2.l.google.com:19302',
                        'stun:stun3.l.google.com:19302',
                        'stun:stun4.l.google.com:19302',
                        'stun:stun.voipbuster.com',
                        'stun:stun.voipstunt.com',
                        'stun:stun.ekiga.net'
                    ]
                },
                {
                    urls: 'turn:numb.viagenie.ca',
                    credential: 'muazkh',
                    username: 'webrtc@live.com'
                }
            ],
            iceCandidatePoolSize: 10,
            bundlePolicy: 'max-bundle',
            rtcpMuxPolicy: 'require',
            iceTransportPolicy: 'all',
            sdpSemantics: 'unified-plan',
            // Add additional configuration for better cross-platform support
            optional: [
                { DtlsSrtpKeyAgreement: true },
                { RtpDataChannels: true }
            ],
            // Add codec preferences for better mobile support
            codecs: {
                audio: [
                    { name: 'opus', clockRate: 48000, numChannels: 2 },
                    { name: 'PCMU', clockRate: 8000, numChannels: 1 },
                    { name: 'PCMA', clockRate: 8000, numChannels: 1 }
                ],
                video: [
                    { name: 'VP8', clockRate: 90000 },
                    { name: 'H264', clockRate: 90000, profile: '42e01f' },
                    { name: 'VP9', clockRate: 90000 }
                ]
            }
        };

        this.setupEventListeners();
    }

    setupEventListeners() {
        // Show video call button when a user is selected
        $(document).on('click', '.contact-li', (e) => {
            const userId = $(e.currentTarget).attr('user-id');
            const groupId = $(e.currentTarget).attr('data-group-id');
            
            if (userId) {
                $('#start-video-call').show();
                $('#start-group-video-call').hide();
                this.remoteUserId = userId;
                this.isGroupCall = false;
            } else if (groupId) {
                $('#start-video-call').hide();
                $('#start-group-video-call').show();
                this.isGroupCall = true;
            } else {
                $('#start-video-call').hide();
                $('#start-group-video-call').hide();
                this.remoteUserId = null;
                this.isGroupCall = false;
            }
        });

        // Start call button
        $('#start-video-call').on('click', () => {
            if (this.remoteUserId) {
                this.startCall(this.remoteUserId);
            }
        });

        // Call controls
        $('#toggleMute').on('click', () => this.toggleAudio());
        $('#toggleVideo').on('click', () => this.toggleVideo());
        $('#endCall').on('click', () => this.endCall());

        // Modal close handler
        $('#videoCallModal').on('hidden.bs.modal', () => {
            this.endCall();
        });

        // Add permission retry handler
        $('#retryPermissions').on('click', async () => {
            $('#permissionInstructions').addClass('d-none');
            const success = await this.checkPermissions();
            if (success) {
                $('#permissionModal').modal('hide');
                if (this.pendingCall) {
                    this.startCall(this.pendingCall);
                    this.pendingCall = null;
                } else if (this.pendingGroupCall) {
                    const groupId = this.pendingGroupCall;
                    this.pendingGroupCall = null;
                    $('#start-group-video-call').click();
                }
            }
        });
    }

    handleWebSocketMessage(data) {
        if (data.type === 'video-call') {
            switch (data.action) {
                case 'offer':
                    this.handleOffer(data);
                    break;
                case 'answer':
                    this.handleAnswer(data);
                    break;
                case 'candidate':
                    this.handleCandidate(data);
                    break;
                case 'end-call':
                    this.handleEndCall();
                    break;
            }
        } else if (data.type === 'user_joined') {
            if (this.isGroupCall) {
                this.handleUserJoined(data);
            }
        } else if (data.type === 'user_disconnected') {
            if (this.isGroupCall) {
                this.handleUserLeft(data);
            }
        } else if (data.type === 'offer') {
            if (this.isGroupCall && data.to_user_id === currentUserId) {
                this.handleGroupOffer(data);
            }
        } else if (data.type === 'answer') {
            if (this.isGroupCall && data.to_user_id === currentUserId) {
                this.handleGroupAnswer(data);
            }
        } else if (data.type === 'ice_candidate') {
            if (this.isGroupCall && data.to_user_id === currentUserId) {
                this.handleGroupCandidate(data);
            }
        } else if (data.type === 'participants_list') {
            if (this.isGroupCall) {
                this.handleParticipantsList(data);
            }
        }
    }

    async checkPermissions() {
        try {
            // First check if getUserMedia is supported
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('Your browser does not support video calls');
            }

            // Update status badges to checking
            $('#cameraStatus, #micStatus').text('Checking...').removeClass().addClass('status-badge status-checking');

            // Check permissions status
            const permissions = await navigator.permissions.query({ name: 'camera' });
            const micPermissions = await navigator.permissions.query({ name: 'microphone' });

            // Update UI based on permission status
            this.updatePermissionStatus('camera', permissions.state);
            this.updatePermissionStatus('mic', micPermissions.state);

            // If either permission is denied, show instructions
            if (permissions.state === 'denied' || micPermissions.state === 'denied') {
                $('#permissionInstructions').removeClass('d-none');
                return false;
            }

            // If permissions are granted, try to access devices
            if (permissions.state === 'granted' && micPermissions.state === 'granted') {
                await this.setupLocalStream();
                return true;
            }

            // If permissions are prompt, show the browser's permission dialog
            if (permissions.state === 'prompt' || micPermissions.state === 'prompt') {
                await this.setupLocalStream();
                return true;
            }

        } catch (error) {
            console.error('Error checking permissions:', error);
            this.updatePermissionStatus('camera', 'denied');
            this.updatePermissionStatus('mic', 'denied');
            $('#permissionInstructions').removeClass('d-none');
            return false;
        }
    }

    updatePermissionStatus(device, state) {
        const statusElement = device === 'camera' ? '#cameraStatus' : '#micStatus';
        $(statusElement).removeClass().addClass('status-badge');
        
        switch (state) {
            case 'granted':
                $(statusElement).addClass('status-granted').text('Allowed');
                break;
            case 'denied':
                $(statusElement).addClass('status-denied').text('Blocked');
                break;
            case 'prompt':
                $(statusElement).addClass('status-checking').text('Waiting...');
                break;
            default:
                $(statusElement).addClass('status-checking').text('Unknown');
        }
    }

    async setupLocalStream() {
        try {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                throw new Error('Your browser does not support video calls');
            }

            // Stop any existing tracks
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => track.stop());
            }

            // Check if we're on a mobile device
            const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            
            // Request permissions with appropriate constraints for the device
            const constraints = {
                video: {
                    width: { ideal: isMobile ? 640 : 1280 },
                    height: { ideal: isMobile ? 480 : 720 },
                    facingMode: 'user',
                    frameRate: { ideal: 30 },
                    aspectRatio: { ideal: 1.7777777778 } // 16:9
                },
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    sampleRate: { ideal: 48000 },
                    channelCount: { ideal: 2 }
                }
            };

            // Try to get media with constraints
            this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
            
            if (this.localVideo) {
                this.localVideo.srcObject = this.localStream;
                console.log('Local stream set up successfully');
                
                // Set up media recording if supported
                try {
                    this.setupMediaRecording(this.localStream);
                } catch (error) {
                    console.warn('Media recording not supported:', error);
                }
                
                return true;
            } else {
                throw new Error('Local video element not found');
            }
        } catch (error) {
            console.error('Error accessing media devices:', error);
            let errorMessage = this.getErrorMessage(error);
            this.showPermissionAlert(errorMessage);
            throw error;
        }
    }

    setupMediaRecording(stream) {
        // Initialize recorded chunks array
        this.recordedChunks = [];
        
        // Create MediaRecorder instance
        this.mediaRecorder = new MediaRecorder(stream, {
            mimeType: 'video/webm;codecs=vp9,opus'
        });

        // Handle data available event
        this.mediaRecorder.ondataavailable = (event) => {
            if (event.data.size > 0) {
                this.recordedChunks.push(event.data);
            }
        };

        // Start recording
        this.mediaRecorder.start();
    }

    getErrorMessage(error) {
        switch (error.name) {
            case 'NotAllowedError':
            case 'PermissionDeniedError':
                return 'Please allow access to your camera and microphone to make video calls.';
            case 'NotFoundError':
            case 'DevicesNotFoundError':
                return 'No camera or microphone found. Please check your devices.';
            case 'NotReadableError':
            case 'TrackStartError':
                return 'Your camera or microphone is already in use by another application.';
            case 'OverconstrainedError':
                return 'Could not find suitable camera settings. Please check your device.';
            case 'TypeError':
                return 'Your browser does not support video calls. Please try a different browser.';
            default:
                return 'Failed to access camera and microphone. Please check your permissions and try again.';
        }
    }

    showPermissionAlert(message) {
        // Remove any existing alerts
        $('.permission-alert').remove();
        
        const alertHtml = `
            <div class="permission-alert alert alert-warning alert-dismissible fade show" role="alert" 
                 style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 9999; 
                        min-width: 300px; background-color: #2c2c2c; color: white; border: 1px solid #ffc107;">
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <div>
                        <strong>Permission Required</strong><br>
                        ${message}
                        <div class="mt-2">
                            <small>
                                How to enable:<br>
                                1. Click the camera icon in your browser's address bar<br>
                                2. Select "Allow" for both camera and microphone<br>
                                3. Refresh the page and try again
                            </small>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        $('body').append(alertHtml);

        // Auto-dismiss after 15 seconds
        setTimeout(() => {
            $('.permission-alert').fadeOut(300, function() {
                $(this).remove();
            });
        }, 15000);
    }

    async startCall(remoteUserId) {
        try {
            this.isInitiator = true;
            this.remoteUserId = remoteUserId;
            
            // Show permission modal
            $('#permissionModal').modal('show');
            
            // First set up local stream
            const streamSuccess = await this.setupLocalStream();
            if (!streamSuccess) {
                return;
            }

            // Then create peer connection
            const peerSuccess = await this.createPeerConnection();
            if (!peerSuccess) {
                return;
            }
            
            // Create and send offer
            const offer = await this.peerConnection.createOffer({
                offerToReceiveAudio: true,
                offerToReceiveVideo: true
            });
            
            await this.peerConnection.setLocalDescription(offer);
            
            this.sendSignalingMessage({
                type: 'video-call',
                action: 'offer',
                offer: offer,
                to: remoteUserId
            });

            $('#permissionModal').modal('hide');
            $('#videoCallModal').modal('show');
            this.addCallStatusMessage('You started a video chat');
        } catch (error) {
            console.error('Error starting call:', error);
            this.showPermissionAlert('Failed to start video call. Please try again.');
        }
    }

    async handleOffer(data) {
        try {
            this.isInitiator = false;
            this.remoteUserId = data.from;
            
            // Show permission modal first
            $('#permissionModal').modal('show');
            
            // Check permissions and setup local stream first
            const permissionsGranted = await this.checkPermissions();
            if (!permissionsGranted) {
                this.pendingCall = data.from;
                return;
            }

            // Create peer connection before showing call notification
            await this.createPeerConnection();

            // Set remote description immediately after peer connection is created
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));

            // Show call notification only after permissions are granted
            $('#permissionModal').modal('hide');
            
            // Show custom call notification
            const callerName = $(`.contact-li[user-id="${data.from}"] .user_info span`).text();
            $('#callerName').text(callerName || 'Unknown User');
            
            // Get caller's avatar if available
            const callerAvatar = $(`.contact-li[user-id="${data.from}"] .user_img`).attr('src');
            if (callerAvatar) {
                $('#callerAvatar').attr('src', callerAvatar);
            }

            // Show notification
            $('#callNotification').show();

            // Handle accept/reject buttons
            return new Promise((resolve, reject) => {
                const cleanup = () => {
                    $('#callNotification').hide();
                    $('#acceptCall').off('click');
                    $('#rejectCall').off('click');
                };

                $('#acceptCall').one('click', async () => {
                    cleanup();
                    try {
                        const answer = await this.peerConnection.createAnswer();
                        await this.peerConnection.setLocalDescription(answer);
                        
                        this.sendSignalingMessage({
                            type: 'video-call',
                            action: 'answer',
                            answer: answer,
                            to: data.from
                        });

                        // Process any pending ICE candidates
                        if (this.pendingCandidates.length > 0) {
                            console.log('Processing pending candidates after accepting call');
                            for (const candidate of this.pendingCandidates) {
                                await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
                            }
                            this.pendingCandidates = [];
                        }

                        $('#videoCallModal').modal('show');
                        this.addCallStatusMessage('Video chat started');
                        resolve();
                    } catch (error) {
                        console.error('Error accepting call:', error);
                        reject(error);
                    }
                });

                $('#rejectCall').one('click', () => {
                    cleanup();
                    this.sendSignalingMessage({
                        type: 'video-call',
                        action: 'end-call',
                        to: data.from
                    });
                    this.addCallStatusMessage('Video chat rejected');
                    this.handleEndCall();
                    resolve();
                });
            });
        } catch (error) {
            console.error('Error handling offer:', error);
            $('#callNotification').hide();
            this.showPermissionAlert('Failed to handle incoming call. Please try again.');
        }
    }

    async handleAnswer(data) {
        try {
            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
        } catch (error) {
            console.error('Error handling answer:', error);
        }
    }

    async handleCandidate(data) {
        try {
            if (!data.candidate) return;

            // If peer connection doesn't exist or is in wrong state, queue the candidate
            if (!this.peerConnection || 
                !this.peerConnection.remoteDescription || 
                !this.peerConnection.localDescription) {
                console.log('Queuing ICE candidate - connection not ready');
                this.pendingCandidates.push(data.candidate);
                return;
            }

            // Add the ICE candidate if connection is ready
            await this.peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
            console.log('Successfully added ICE candidate');
        } catch (error) {
            console.error('Error handling ICE candidate:', error);
            // Don't throw the error, just log it and continue
            // Queue the candidate for later if there was an error
            this.pendingCandidates.push(data.candidate);
        }
    }

    async createPeerConnection() {
        try {
            if (this.peerConnection) {
                // Clean up existing connection
                this.peerConnection.close();
                this.peerConnection = null;
            }

            this.peerConnection = new RTCPeerConnection(this.configuration);
            console.log('Peer connection created');

            // Add local stream tracks to peer connection
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => {
                    this.peerConnection.addTrack(track, this.localStream);
                });
                console.log('Added local tracks to peer connection');
            } else {
                throw new Error('Local stream not initialized');
            }

            // Handle incoming stream
            this.peerConnection.ontrack = (event) => {
                console.log('Received remote track');
                if (event.streams && event.streams[0]) {
                    this.remoteVideo.srcObject = event.streams[0];
                    this.remoteStream = event.streams[0];
                }
            };

            // Handle ICE candidates
            this.peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    console.log('Generated local ICE candidate');
                    this.sendSignalingMessage({
                        type: 'video-call',
                        action: 'candidate',
                        candidate: event.candidate,
                        to: this.remoteUserId
                    });
                }
            };

            // Handle ICE connection state changes
            this.peerConnection.oniceconnectionstatechange = () => {
                console.log('ICE connection state:', this.peerConnection.iceConnectionState);
                switch (this.peerConnection.iceConnectionState) {
                    case 'failed':
                        console.log('ICE connection failed - restarting ICE');
                        this.peerConnection.restartIce();
                        break;
                    case 'disconnected':
                        console.log('ICE connection disconnected - attempting to reconnect');
                        setTimeout(() => {
                            if (this.peerConnection.iceConnectionState === 'disconnected') {
                                this.peerConnection.restartIce();
                            }
                        }, 5000);
                        break;
                }
            };

            // Handle connection state changes
            this.peerConnection.onconnectionstatechange = () => {
                console.log('Connection state:', this.peerConnection.connectionState);
                switch (this.peerConnection.connectionState) {
                    case 'connected':
                        console.log('Peers connected successfully');
                        this.addCallStatusMessage('Connected');
                        break;
                    case 'failed':
                        console.log('Connection failed - attempting to reconnect');
                        this.handleConnectionFailure();
                        break;
                    case 'disconnected':
                        console.log('Connection disconnected - attempting to reconnect');
                        setTimeout(() => {
                            if (this.peerConnection.connectionState === 'disconnected') {
                                this.handleConnectionFailure();
                            }
                        }, 5000);
                        break;
                    case 'closed':
                        console.log('Peer connection closed');
                        break;
                }
            };

            // Handle signaling state changes
            this.peerConnection.onsignalingstatechange = () => {
                console.log('Signaling state:', this.peerConnection.signalingState);
            };

            return true;
        } catch (error) {
            console.error('Error creating peer connection:', error);
            this.showPermissionAlert('Failed to create peer connection. Please try again.');
            return false;
        }
    }

    sendSignalingMessage(message) {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(message));
        } else {
            console.error('WebSocket is not connected');
            alert('Connection error. Please refresh the page and try again.');
        }
    }

    toggleAudio() {
        if (this.localStream) {
            this.isAudioMuted = !this.isAudioMuted;
            this.localStream.getAudioTracks().forEach(track => {
                track.enabled = !this.isAudioMuted;
            });
            $('#toggleMute i').toggleClass('fa-microphone fa-microphone-slash');
        }
    }

    toggleVideo() {
        if (this.localStream) {
            this.isVideoOff = !this.isVideoOff;
            this.localStream.getVideoTracks().forEach(track => {
                track.enabled = !this.isVideoOff;
            });
            $('#toggleVideo i').toggleClass('fa-video fa-video-slash');
        }
    }

    endCall() {
        if (this.callEnded) return;
        this.callEnded = true;

        console.log('Ending call');
        
        // Handle based on call type
        if (this.isGroupCall) {
            this.leaveGroupCall();
        } else {
            // One-to-one call handling
            if (this.peerConnection) {
                // Send end-call message to the other user
                this.sendSignalingMessage({
                    action: 'end-call',
                    from: USER_ID,
                    to: this.remoteUserId
                });

                this.peerConnection.close();
                this.peerConnection = null;
            }

            // Stop media recording if active
            if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
                this.mediaRecorder.stop();
            }

            // Clean up media streams
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => track.stop());
                this.localVideo.srcObject = null;
                this.localStream = null;
            }

            if (this.remoteStream) {
                this.remoteStream.getTracks().forEach(track => track.stop());
                if (this.remoteVideo) {
                    this.remoteVideo.srcObject = null;
                }
                this.remoteStream = null;
            }
        }

        // UI cleanup
        $('#videoCallModal').modal('hide');
        $('.call-notification').hide();
        
        // Reset call state
        this.isInitiator = false;
        this.remoteUserId = null;
        this.isAudioMuted = false;
        this.isVideoOff = false;
        
        // Add call ended message
        this.addCallStatusMessage('Call ended');
        
        // Reset permisions and warning flags
        $('#permissionInstructions').addClass('d-none');
        $('.permission-alert').remove();
    }

    handleEndCall() {
        // Only add end message if we haven't already ended the call
        if (this.peerConnection && !this.callEnded) {
            this.addCallStatusMessage('Video chat ended');
            this.callEnded = true;  // Mark call as ended
        }

        // Stop recording if active
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
        }

        // Stop all tracks
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
        }
        if (this.remoteStream) {
            this.remoteStream.getTracks().forEach(track => track.stop());
        }

        // Clear video elements
        if (this.localVideo) this.localVideo.srcObject = null;
        if (this.remoteVideo) this.remoteVideo.srcObject = null;

        // Close peer connection
        if (this.peerConnection) {
            this.peerConnection.close();
            this.peerConnection = null;
        }

        // Reset state
        this.localStream = null;
        this.remoteStream = null;
        this.isInitiator = false;
        this.recordedChunks = [];
        this.mediaRecorder = null;

        // Hide modal
        $('#videoCallModal').modal('hide');

        // Reset UI
        $('#toggleMute i').removeClass('fa-microphone-slash').addClass('fa-microphone');
        $('#toggleVideo i').removeClass('fa-video-slash').addClass('fa-video');
    }

    handleConnectionFailure() {
        this.showPermissionAlert('Connection failed. This might be due to network issues or firewall settings.');
        this.endCall();
    }

    // Add method to display call status messages
    addCallStatusMessage(message) {
        const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const statusHtml = `
            <div class="text-center my-2">
                <div class="call-status-message">
                    ${message}
                    <div class="call-time">${currentTime}</div>
                </div>
            </div>
        `;
        $('.msg_card_body').append(statusHtml);
        // Scroll to bottom
        $('.msg_card_body').scrollTop($('.msg_card_body')[0].scrollHeight);
    }

    // Group call functions
    async initializeGroupCall(roomName, participants) {
        this.isGroupCall = true;
        this.roomName = roomName;
        
        try {
            // Set up local stream if not already done
            if (!this.localStream) {
                await this.setupLocalStream();
            }
            
            // Create peer connections for each participant
            for (const participant of participants) {
                if (participant.user_id !== currentUserId) {
                    await this.createGroupPeerConnection(participant.user_id);
                }
            }
            
            // Listen for new participants
            this.socket.send(JSON.stringify({
                action: 'join',
                room_name: roomName,
                stream_id: `${currentUserId}_${Date.now()}`
            }));
            
        } catch (error) {
            console.error('Error initializing group call:', error);
            this.handleConnectionFailure();
        }
    }
    
    async createGroupPeerConnection(participantId) {
        try {
            const peerConnection = new RTCPeerConnection(this.configuration);
            this.peerConnections[participantId] = peerConnection;
            
            // Add local tracks
            if (this.localStream) {
                this.localStream.getTracks().forEach(track => {
                    peerConnection.addTrack(track, this.localStream);
                });
            }
            
            // Set up event handlers
            peerConnection.onicecandidate = (event) => {
                if (event.candidate) {
                    this.socket.send(JSON.stringify({
                        action: 'ice_candidate',
                        candidate: event.candidate,
                        from_user_id: currentUserId,
                        to_user_id: participantId
                    }));
                }
            };
            
            peerConnection.ontrack = (event) => {
                if (event.streams && event.streams[0]) {
                    this.addRemoteVideoForGroupCall(participantId, event.streams[0]);
                }
            };
            
            peerConnection.oniceconnectionstatechange = () => {
                this.updateGroupConnectionStatus(participantId, peerConnection.iceConnectionState);
            };
            
            // Create and send offer
            const offer = await peerConnection.createOffer();
            await peerConnection.setLocalDescription(offer);
            
            this.socket.send(JSON.stringify({
                action: 'offer',
                offer: offer,
                from_user_id: currentUserId,
                to_user_id: participantId
            }));
            
            return peerConnection;
        } catch (error) {
            console.error('Error creating group peer connection:', error);
            this.handleConnectionFailure();
        }
    }
    
    addRemoteVideoForGroupCall(participantId, stream) {
        // Check if we already have a video element for this participant
        let remoteVideo = document.querySelector(`#remote-video-${participantId}`);
        
        if (!remoteVideo) {
            // Create a new container for this participant
            const videoContainer = document.createElement('div');
            videoContainer.className = 'video-wrapper';
            videoContainer.dataset.userId = participantId;
            
            // Create video element
            remoteVideo = document.createElement('video');
            remoteVideo.id = `remote-video-${participantId}`;
            remoteVideo.autoplay = true;
            remoteVideo.playsInline = true;
            
            // Create participant name element
            const participantName = document.createElement('div');
            participantName.className = 'participant-name';
            // You'll need to set the name based on your application's data
            participantName.textContent = 'Participant';
            
            // Create connection status element
            const connectionStatus = document.createElement('div');
            connectionStatus.className = 'connection-status';
            connectionStatus.id = `connection-status-${participantId}`;
            connectionStatus.textContent = 'Connecting...';
            
            // Append all elements to the container
            videoContainer.appendChild(remoteVideo);
            videoContainer.appendChild(participantName);
            videoContainer.appendChild(connectionStatus);
            
            // Add container to the video grid
            document.getElementById('videoGrid').appendChild(videoContainer);
        }
        
        // Set the stream as the source for the video element
        remoteVideo.srcObject = stream;
    }
    
    updateGroupConnectionStatus(participantId, state) {
        const statusElement = document.getElementById(`connection-status-${participantId}`);
        if (!statusElement) return;
        
        let statusClass = '';
        let statusText = '';
        
        switch (state) {
            case 'connected':
                statusClass = 'connected';
                statusText = 'Connected';
                break;
            case 'checking':
                statusClass = 'connecting';
                statusText = 'Connecting...';
                break;
            case 'disconnected':
            case 'failed':
                statusClass = 'disconnected';
                statusText = 'Disconnected';
                // Try to reconnect
                this.handleGroupConnectionFailure(participantId);
                break;
            default:
                statusClass = 'connecting';
                statusText = 'Connecting...';
        }
        
        statusElement.className = `connection-status ${statusClass}`;
        statusElement.textContent = statusText;
    }
    
    handleGroupConnectionFailure(participantId) {
        // Attempt to reconnect
        const peerConnection = this.peerConnections[participantId];
        if (peerConnection) {
            // Create a new offer with ICE restart
            peerConnection.createOffer({ iceRestart: true })
                .then(offer => {
                    peerConnection.setLocalDescription(offer);
                    this.socket.send(JSON.stringify({
                        action: 'offer',
                        offer: offer,
                        from_user_id: currentUserId,
                        to_user_id: participantId,
                        ice_restart: true
                    }));
                })
                .catch(error => {
                    console.error('Error creating ICE restart offer:', error);
                });
        }
    }
    
    leaveGroupCall() {
        // Notify the server we're leaving
        if (this.socket && this.roomName) {
            this.socket.send(JSON.stringify({
                action: 'leave',
                room_name: this.roomName,
                user_id: currentUserId
            }));
        }
        
        // Clean up all peer connections
        for (const [participantId, connection] of Object.entries(this.peerConnections)) {
            connection.close();
        }
        this.peerConnections = {};
        
        // Stop local stream
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }
        
        // Clean up UI
        this.clearGroupVideoElements();
    }
    
    clearGroupVideoElements() {
        // Keep only the local video container
        const videoGrid = document.getElementById('videoGrid');
        const localContainer = document.querySelector('.local-video');
        
        if (videoGrid && localContainer) {
            videoGrid.innerHTML = '';
            videoGrid.appendChild(localContainer);
        }
    }

    async handleUserJoined(data) {
        const userId = data.user_id;
        if (userId !== currentUserId && !this.peerConnections[userId]) {
            await this.createGroupPeerConnection(userId);
        }
    }
    
    handleUserLeft(data) {
        const userId = data.user_id;
        // Close the peer connection
        if (this.peerConnections[userId]) {
            this.peerConnections[userId].close();
            delete this.peerConnections[userId];
        }
        
        // Remove the video element
        const videoContainer = document.querySelector(`[data-user-id="${userId}"]`);
        if (videoContainer) {
            videoContainer.remove();
        }
    }
    
    async handleGroupOffer(data) {
        try {
            // Create peer connection if it doesn't exist
            let peerConnection = this.peerConnections[data.from_user_id];
            if (!peerConnection) {
                peerConnection = new RTCPeerConnection(this.configuration);
                this.peerConnections[data.from_user_id] = peerConnection;
                
                // Add local tracks
                if (this.localStream) {
                    this.localStream.getTracks().forEach(track => {
                        peerConnection.addTrack(track, this.localStream);
                    });
                }
                
                // Set up event handlers
                peerConnection.onicecandidate = (event) => {
                    if (event.candidate) {
                        this.socket.send(JSON.stringify({
                            action: 'ice_candidate',
                            candidate: event.candidate,
                            from_user_id: currentUserId,
                            to_user_id: data.from_user_id
                        }));
                    }
                };
                
                peerConnection.ontrack = (event) => {
                    if (event.streams && event.streams[0]) {
                        this.addRemoteVideoForGroupCall(data.from_user_id, event.streams[0]);
                    }
                };
                
                peerConnection.oniceconnectionstatechange = () => {
                    this.updateGroupConnectionStatus(data.from_user_id, peerConnection.iceConnectionState);
                };
            }
            
            // Set remote description (the offer)
            await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
            
            // Create and send answer
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);
            
            this.socket.send(JSON.stringify({
                action: 'answer',
                answer: answer,
                from_user_id: currentUserId,
                to_user_id: data.from_user_id
            }));
        } catch (error) {
            console.error('Error handling group offer:', error);
        }
    }
    
    async handleGroupAnswer(data) {
        try {
            const peerConnection = this.peerConnections[data.from_user_id];
            if (peerConnection) {
                await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
            }
        } catch (error) {
            console.error('Error handling group answer:', error);
        }
    }
    
    async handleGroupCandidate(data) {
        try {
            const peerConnection = this.peerConnections[data.from_user_id];
            if (peerConnection) {
                await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
            }
        } catch (error) {
            console.error('Error handling group ICE candidate:', error);
        }
    }
    
    handleParticipantsList(data) {
        // Initialize connections with all current participants
        if (data.participants && data.participants.length > 0) {
            for (const participant of data.participants) {
                if (participant.user_id !== currentUserId && !this.peerConnections[participant.user_id]) {
                    this.createGroupPeerConnection(participant.user_id);
                }
            }
        }
    }
} 